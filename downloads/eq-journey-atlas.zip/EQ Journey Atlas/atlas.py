#!/usr/bin/env python3
"""
EverQuest Journey Atlas - one command updates everything.

    python atlas.py               # read the logs, merge, rebuild every chart, write in-game layers
    python atlas.py --watch       # keep running while you play: update every 5 minutes
    python atlas.py --no-ingame   # skip writing map layers into the EverQuest folder
    python atlas.py --dry-run     # show what it would do
    python atlas.py --publish-now # build the public pages and publish them straight away

Everything it needs is described in config.json next to this file.
"""
import json, os, sys, glob, shutil, re, argparse, time
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import eq_log_parser as parser
import build_viewer as viewer

EQ_GUESSES = [
    r"C:\Users\Public\Daybreak Game Company\Installed Games\EverQuest",
    r"C:\Program Files (x86)\Steam\steamapps\common\EverQuest",
    r"C:\Program Files (x86)\Sony\EverQuest",
    r"C:\EverQuest",
]

def load_config():
    raw = open(os.path.join(HERE, "config.json"), encoding="utf-8").read()
    try:
        cfg = json.loads(raw)
    except json.JSONDecodeError:
        # a Windows path typed with single backslashes ("C:\Users\...") isn't valid JSON; forgive it.
        # Already-doubled backslashes are left alone.
        fixed = re.sub(r'\\\\|\\(?!["/bfnrtu])', lambda m: '\\\\', raw)
        cfg = json.loads(fixed)
    eq = cfg.get("eq_dir") or next((g for g in EQ_GUESSES if os.path.isdir(g)), None)
    if not eq or not os.path.isdir(eq):
        sys.exit("Can't find the EverQuest folder. Set \"eq_dir\" in config.json to your EverQuest install folder "
                 "(the one containing eqgame.exe, Logs\\ and maps\\).")
    cfg["eq_dir"] = eq
    cfg["logs_dir"] = os.path.join(eq, cfg.get("logs_subdir", "Logs"))
    cfg["maps_dir"] = os.path.join(eq, cfg.get("maps_subdir", os.path.join("maps", "Brewall")))
    cfg["out"] = os.path.join(HERE, "journey")
    cfg["backups"] = os.path.join(HERE, "backups")
    cfg["brewall_originals"] = os.path.join(HERE, "brewall_originals")
    cfg["shots"] = os.path.join(HERE, cfg.get("screenshots_dir", "Atlas Screenshots"))
    detect_character(cfg)
    if not cfg.get("team"):
        cfg["team"] = [cfg["character"]] if cfg.get("character") else []
    return cfg

def detect_character(cfg):
    """Fill in server/character from the newest log file when config.json leaves them blank."""
    if cfg.get("server") and cfg.get("character"): return
    logs = sorted(glob.glob(os.path.join(cfg["logs_dir"], "eqlog_*_*.txt")), key=os.path.getmtime)
    if not logs: return
    m = re.match(r"eqlog_(.+?)_(.+)\.txt$", os.path.basename(logs[-1]), re.I)
    if not m: return
    if not cfg.get("server"): cfg["server"] = m.group(2)
    if not cfg.get("character"): cfg["character"] = m.group(1)

def ensure_shot_folders(cfg, journey):
    """One subfolder per zone the journey knows, named by the zone; drop screenshots in and they get pinned."""
    os.makedirs(cfg["shots"], exist_ok=True)
    made = []
    for v in journey["visits"]:
        if not v.get("zone_short"): continue
        folder = os.path.join(cfg["shots"], re.sub(r'[<>:"/\\|?*]', "", v["zone"]))
        if not os.path.isdir(folder):
            os.makedirs(folder); made.append(v["zone"])
    return made

def find_logs(cfg):
    pat = os.path.join(cfg["logs_dir"], f"eqlog_*_{cfg['server']}.txt")
    logs = sorted(glob.glob(pat))
    if cfg.get("only_character"):
        logs = [l for l in logs if os.path.basename(l).lower() == f"eqlog_{cfg['only_character'].lower()}_{cfg['server'].lower()}.txt"]
    return logs

def backup_journey(cfg):
    j = os.path.join(cfg["out"], "eq_journey.json")
    if not os.path.exists(j): return
    os.makedirs(cfg["backups"], exist_ok=True)
    # When the atlas runs every few minutes, keep at most one backup per hour so the
    # kept backups cover the last several hours rather than the last few runs.
    prev = sorted(glob.glob(os.path.join(cfg["backups"], "eq_journey_*.json")))
    if prev:
        try:
            last = datetime.strptime(os.path.basename(prev[-1])[11:26], "%Y%m%d_%H%M%S")
            if (datetime.now() - last).total_seconds() < 3600: return
        except ValueError:
            pass
    dst = os.path.join(cfg["backups"], datetime.now().strftime("eq_journey_%Y%m%d_%H%M%S.json"))
    shutil.copy2(j, dst)
    keep = cfg.get("backups_to_keep", 10)
    old = sorted(glob.glob(os.path.join(cfg["backups"], "eq_journey_*.json")))
    for f in old[:-keep]: os.remove(f)

def seed_named(cfg, journey):
    """For any charted zone with no entry in named_mobs.json, pull Brewall's (Raid)/(Hunter) markers."""
    p = os.path.join(cfg["out"], "named_mobs.json")
    named = json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {}
    added = []
    for v in journey["visits"]:
        z = v["zone_short"]
        if not z or z in named: continue
        f1 = os.path.join(cfg["maps_dir"], f"{z}_1.txt")
        if not os.path.exists(f1): continue
        out = set()
        for raw in open(f1, encoding="utf-8", errors="replace"):
            if not raw.startswith("P"): continue
            parts = raw.strip().split(",")
            if len(parts) < 8: continue
            lab = parts[7].strip()
            if "(Raid" in lab or "(Hunter" in lab:
                out.add(re.sub(r"_\(.*$", "", lab).replace("_", " "))
        named[z] = sorted(out); added.append((z, len(out)))
    if added:
        json.dump(named, open(p, "w", encoding="utf-8"), indent=1)
    return added

def add_pins(cfg, z):
    """Append the hand-made pins in Atlas/pins/<zone>.txt (if any) to the zone's _3 layer."""
    pf = os.path.join(HERE, "pins", f"{z}.txt")
    if not os.path.exists(pf): return
    lines = [l.strip() for l in open(pf, encoding="utf-8") if l.strip() and not l.lstrip().startswith("#")]
    if lines:
        with open(os.path.join(cfg["maps_dir"], f"{z}_3.txt"), "a", encoding="utf-8") as f:
            f.write("\n" + "\n".join(lines) + "\n")

def write_ingame_layers(cfg, dry=False):
    """Write each <zone>_journey.txt as <zone>_3.txt in the Brewall folder: the journey gets its own layer
    checkbox in the map window and Brewall's files are never touched. If an earlier version of the atlas
    merged the journey into a <zone>_2.txt, that file is restored from brewall_originals/."""
    written, restored = [], []
    for jf in glob.glob(os.path.join(cfg["out"], "*_journey.txt")):
        z = os.path.basename(jf)[:-len("_journey.txt")]
        if not os.path.exists(os.path.join(cfg["maps_dir"], f"{z}.txt")): continue   # no map for this zone
        orig = os.path.join(cfg["brewall_originals"], f"{z}_2.txt")
        if os.path.exists(orig):
            shutil.copy2(orig, os.path.join(cfg["maps_dir"], f"{z}_2.txt")); os.remove(orig); restored.append(z)
            stamp = os.path.join(cfg["brewall_originals"], f"{z}_2.written")
            if os.path.exists(stamp): os.remove(stamp)
        if not dry:
            shutil.copy2(jf, os.path.join(cfg["maps_dir"], f"{z}_3.txt"))
            add_pins(cfg, z)
        written.append(z)
    # zones that have custom pins but no journey layer yet
    for pf in glob.glob(os.path.join(HERE, "pins", "*.txt")):
        z = os.path.basename(pf)[:-4]
        if z in written or not os.path.exists(os.path.join(cfg["maps_dir"], f"{z}.txt")): continue
        if not dry:
            open(os.path.join(cfg["maps_dir"], f"{z}_3.txt"), "w", encoding="utf-8").close()
            add_pins(cfg, z)
        written.append(z)
    if restored: print(f"Brewall's _2 files restored: {', '.join(sorted(restored))}")
    return written

def run_once(cfg, a):
    logs = find_logs(cfg)
    if not logs:
        sys.exit(f"No logs found in {cfg['logs_dir']} (looking for eqlog_*_{cfg['server']}.txt). "
                 "In game, type /log on once per character, then play a little and run this again.")
    print(f"EverQuest: {cfg['eq_dir']}")
    print(f"Logs:      {', '.join(os.path.basename(l) for l in logs)}")
    print(f"Maps:      {cfg['maps_dir']}")
    if a.dry_run:
        print("(dry run - nothing written)"); return

    parser.set_team(cfg["team"])
    viewer.TEAM = set(cfg["team"])
    parser.load_zone_names(os.path.join(HERE, "zone_names.json"))
    backup_journey(cfg)
    journey = parser.run(logs, cfg["out"], char=cfg["character"])

    for z, n in seed_named(cfg, journey):
        print(f"Named list seeded for {z}: {n} from Brewall's markers")
    made = ensure_shot_folders(cfg, journey)
    if made: print(f"Screenshot folders added under {os.path.basename(cfg['shots'])}: {', '.join(made)}")

    # charts + index
    viewer.JOURNEY_PATH = os.path.join(cfg["out"], "eq_journey.json")
    viewer.CHARTS = True
    import build_chart
    build_chart.JOURNAL = build_chart.load_journal(os.path.join(HERE, "journal.md"))
    build_chart.SHOTS_DIR = cfg["shots"]
    viewer.build_all(viewer.JOURNEY_PATH, cfg["maps_dir"], cfg["out"])

    if cfg.get("write_ingame_layers", True) and not a.no_ingame:
        z = write_ingame_layers(cfg)
        print(f"In-game layers written: {', '.join(sorted(z))}")
    parser.summary(journey)
    parser.candidates(journey)
    print(f"\nAtlas: {os.path.join(cfg['out'], 'index.html')}")

    pub = cfg.get("publish") or {}
    if pub.get("enabled") or a.publish_now:
        import publish
        publish.maybe_publish(cfg, logs, force=a.publish_now)   # logs its own errors; never stops the atlas

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-ingame", action="store_true", help="don't write layers into the EverQuest maps folder")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--watch", action="store_true", help="keep running, updating every few minutes (Ctrl+C to stop)")
    ap.add_argument("--every", type=float, default=5, help="minutes between updates with --watch (default 5)")
    ap.add_argument("--publish-now", action="store_true", help="publish the public pages now, whatever the schedule")
    a = ap.parse_args()
    cfg = load_config()
    if not a.watch:
        run_once(cfg, a); return
    print(f"Watching: the atlas updates every {a.every:g} minutes. Leave this window open while you play; Ctrl+C stops it.")
    while True:
        try:
            run_once(load_config(), a)
        except SystemExit as e:
            print(e)
        except Exception as e:
            print(f"This update failed and will be tried again: {e}")
        a.publish_now = False
        print(f"\n--- next update {datetime.fromtimestamp(time.time() + a.every*60):%I:%M %p} ---\n")
        time.sleep(a.every * 60)

if __name__ == "__main__":
    main()
