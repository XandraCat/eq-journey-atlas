"""Extra atlas pages built from eq_journey.json: sessions.html, bestiary.html, fallen.html."""
import json, os, html
from collections import defaultdict, Counter
from datetime import datetime

CSS = """
:root{--night:#0a1116;--parch:#e9dcc0;--parch-2:#dccbaa;--ink:#2a2118;--ink-soft:#6b5a45;--gold:#c89b4a;--moss:#7d9c88;--rule:#c9b58e;--red:#7a2e1e}
*{box-sizing:border-box;margin:0}
body{background:var(--night);color:var(--ink);font:16px/1.55 "EB Garamond",Georgia,serif;padding:56px 24px 80px}
main{max-width:1040px;margin:0 auto;background:linear-gradient(160deg,var(--parch),var(--parch-2));border:1px solid #b89b6a;border-radius:3px;padding:48px 56px 56px;box-shadow:0 0 0 3px rgba(233,220,192,.12),0 24px 60px rgba(0,0,0,.5)}
.kicker{font:600 11px/1 Cinzel,serif;letter-spacing:.24em;text-transform:uppercase;color:var(--ink-soft)}
h1{font:700 34px/1.1 Cinzel,serif;letter-spacing:.02em;margin-top:8px}
h2{font:600 13px/1 Cinzel,serif;letter-spacing:.2em;text-transform:uppercase;color:var(--ink-soft);margin:36px 0 12px;padding-bottom:8px;border-bottom:1px solid var(--rule)}
.rule{height:1px;width:220px;background:linear-gradient(90deg,var(--gold),transparent);margin:16px 0 14px}
nav{margin:0 0 6px;font-size:14px}
nav a{color:#8a5a1f;text-decoration:none;margin-right:18px} nav a:hover{text-decoration:underline}
a{color:#8a5a1f;text-decoration:none} a:hover{text-decoration:underline}
p.sub{color:var(--ink-soft);max-width:64ch}
.day{margin:26px 0 0}
.day h3{font:500 22px/1.2 Cinzel,serif;letter-spacing:.02em}
.day .path{color:var(--ink-soft);font-style:italic;margin:4px 0 10px}
.day p{max-width:76ch;margin:6px 0}
.note{margin:10px 0 0;padding:10px 14px;border-left:2px solid var(--gold);font-style:italic}
.note small{display:block;font-style:normal;font:600 10px/1 Cinzel,serif;letter-spacing:.2em;color:var(--ink-soft);margin-bottom:4px}
table{border-collapse:collapse;width:100%;margin-top:6px}
th{text-align:left;font:600 11px/1 Cinzel,serif;letter-spacing:.14em;text-transform:uppercase;color:var(--ink-soft);padding:0 14px 10px 0;border-bottom:1px solid var(--rule)}
td{padding:9px 14px 9px 0;border-bottom:1px solid var(--rule);vertical-align:top}
td.n,th.n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.dim{color:var(--ink-soft)}
.star{color:var(--red);font-variant:small-caps;letter-spacing:.5px;font-weight:500}
@media (max-width:640px){body{padding:24px 12px}main{padding:28px 20px}h1{font-size:24px}}
"""
HEAD = """<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;600;700&family=EB+Garamond:ital,wght@0,400;0,500;1,400&display=swap" rel="stylesheet">
<style>{css}</style></head><body><main>
<nav>{home}<a href="index.html">Atlas</a><a href="sessions.html">Sessions</a><a href="bestiary.html">Bestiary</a><a href="fallen.html">The Fallen</a></nav>
<div class="kicker">{kicker}</div><h1>{h1}</h1><div class="rule"></div>
"""
FOOT = "</main></body></html>"
HOME_LINK = ""   # public site only: link back to the front page

def nice_date(s):
    return datetime.fromisoformat(s[:10]).strftime("%A, %d %B %Y").replace(" 0", " ")

def clock(s):
    return datetime.fromisoformat(s).strftime("%I:%M %p").lstrip("0").lower()

def joined(items):
    items = list(items)
    if not items: return ""
    if len(items) == 1: return items[0]
    return ", ".join(items[:-1]) + " and " + items[-1]

def build_sessions(d, journal, out, party_names=()):
    days = defaultdict(list)
    for v in d["visits"]:
        if v.get("zone_short") and (v["trail"] or v["events"]):
            days[v["entered"][:10]].append(v)
    parts = []
    for day in sorted(days, reverse=True):
        vs = days[day]
        zones = []
        for v in vs:
            if not zones or zones[-1] != v["zone"]: zones.append(v["zone"])
        ev = [e for v in vs for e in v["events"]]
        named = [e for e in ev if e["type"] == "kill" and e.get("named")]
        team = sum(1 for e in ev if e["type"] == "kill" and e.get("team"))
        deaths = [e for e in ev if e["type"] == "death"]
        levels = [e for e in ev if e["type"] == "level"]
        locs = sum(len(v["trail"]) for v in vs)
        sent = []
        if named:
            by_zone = defaultdict(list)
            for e in named: by_zone[next(v["zone"] for v in vs if e in v["events"])].append(e)
            for z, es in by_zone.items():
                names = Counter(e["mob"] for e in es)
                sent.append(f"In {html.escape(z)}, " + joined(f'<span class="star">{html.escape(n)}</span>' + (f" ×{c}" if c > 1 else "") for n, c in names.items()) + (" fell." if len(es) == 1 else " fell."))
        if levels:
            lv = sorted(e["level"] for e in levels)
            sent.append(f"{html.escape(d['character'])} reached level {lv[-1]}." if len(lv) == 1 else f"{html.escape(d['character'])} climbed from {lv[0]} to {lv[-1]}.")
        party = [e for e in deaths if e["who"] in party_names] if party_names else deaths
        others = len(deaths) - len(party)
        if party:
            who = Counter(e["who"] for e in party)
            top = who.most_common(1)[0]
            sent.append(f"{len(party)} death{'s' if len(party) > 1 else ''} in the party" + (f", {html.escape(top[0])} {top[1]} times" if top[1] > 1 else f", {html.escape(top[0])} to {html.escape(party[0]['by'])}") + ".")
        if others:
            sent.append(f"The wider raid lost {others}.")
        stats = f"{locs} readings, {team} kills by the party."
        notes = []
        for key, entries in (journal or {}).items():
            for dt, text in entries:
                if dt == day: notes.append((key, text))
        note_html = "".join(f'<div class="note"><small>{html.escape(k.upper())}</small>{html.escape(t)}</div>' for k, t in notes)
        first = vs[0]["entered"]; last = max([v["entered"] for v in vs] + [e["t"] for e in ev] + [p["t"] for v in vs for p in v["trail"]])
        parts.append(f'''<div class="day"><h3>{nice_date(day)}</h3>
<div class="path">{clock(first)} to {clock(last)} · {" → ".join(html.escape(z) for z in zones)}</div>
<p>{" ".join(sent) if sent else "A quiet day of travel."} <span class="dim">{stats}</span></p>{note_html}</div>''')
    page = HEAD.format(title="Sessions", css=CSS, home=HOME_LINK, kicker="The journey by day", h1=f"{html.escape(d['character'])}'s sessions") + \
        f'<p class="sub">Every day the log has seen, newest first, told from what happened. Journal notes appear on their day.</p>' + "".join(parts) + FOOT
    open(os.path.join(out, "sessions.html"), "w", encoding="utf-8").write(page)

def build_bestiary(d, out, charted):
    rows = defaultdict(lambda: {"n": 0, "first": None, "last": None, "by": Counter(), "zone": None})
    for v in d["visits"]:
        for e in v["events"]:
            if e["type"] == "kill" and e.get("named"):
                r = rows[(v["zone_short"], e["mob"])]
                r["n"] += 1; r["zone"] = v["zone"]; r["by"][e["by"]] += 1
                r["first"] = min(r["first"] or e["t"], e["t"]); r["last"] = max(r["last"] or e["t"], e["t"])
    trs = []
    for (short, mob), r in sorted(rows.items(), key=lambda kv: (kv[1]["zone"], -kv[1]["n"], kv[0][1])):
        z = f'<a href="{short}_chart.html">{html.escape(r["zone"])}</a>' if short in charted else html.escape(r["zone"])
        by = joined(f"{html.escape(k)}" + (f" ×{c}" if c > 1 else "") for k, c in r["by"].most_common(3))
        dates = r["first"][:10] if r["first"][:10] == r["last"][:10] else f'{r["first"][:10]} to {r["last"][:10]}'
        trs.append(f'<tr><td class="star">{html.escape(mob)}</td><td>{z}</td><td class="n">{r["n"]}</td><td>{by}</td><td class="dim">{dates}</td></tr>')
    total = sum(r["n"] for r in rows.values())
    page = HEAD.format(title="Bestiary", css=CSS, home=HOME_LINK, kicker="Named slain", h1="The bestiary") + \
        f'<p class="sub">{len(rows)} named creatures, {total} kills in all. Zone names open the chart where they fell.</p>' + \
        '<table><thead><tr><th>Named</th><th>Zone</th><th class="n">Slain</th><th>By</th><th>When</th></tr></thead><tbody>' + "".join(trs) + "</tbody></table>" + FOOT
    open(os.path.join(out, "bestiary.html"), "w", encoding="utf-8").write(page)

def build_fallen(d, out, charted, team):
    rows = []
    for v in d["visits"]:
        for e in v["events"]:
            if e["type"] == "death" and e["who"] in team:
                rows.append((e["t"], e["who"], e["by"], v["zone"], v["zone_short"]))
    rows.sort(reverse=True)
    by_who = Counter(r[1] for r in rows); by_zone = Counter(r[3] for r in rows)
    trs = "".join(f'<tr><td>{html.escape(w)}</td><td>{html.escape(b)}</td><td>{f"<a href=&quot;{s}_chart.html&quot;>{html.escape(z)}</a>" if s in charted else html.escape(z)}</td><td class="dim">{t[:10]} {clock(t)}</td></tr>' for t, w, b, z, s in rows)
    summary = joined(f"{html.escape(w)} {c}" for w, c in by_who.most_common()) if rows else "no one yet"
    worst = f' The deadliest ground has been {html.escape(by_zone.most_common(1)[0][0])}.' if rows else ""
    page = HEAD.format(title="The Fallen", css=CSS, home=HOME_LINK, kicker="Deaths of the party", h1="The fallen") + \
        f'<p class="sub">{len(rows)} deaths in all: {summary}.{worst}</p>' + \
        '<table><thead><tr><th>Who</th><th>To</th><th>Where</th><th>When</th></tr></thead><tbody>' + trs + "</tbody></table>" + FOOT
    open(os.path.join(out, "fallen.html"), "w", encoding="utf-8").write(page)

def build_all(journey_path, out, journal, charted, team):
    d = json.load(open(journey_path, encoding="utf-8"))
    build_sessions(d, journal, out, set(team))
    build_bestiary(d, out, charted)
    build_fallen(d, out, charted, set(team))
