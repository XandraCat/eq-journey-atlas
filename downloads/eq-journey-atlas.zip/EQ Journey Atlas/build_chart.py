"""Flat, hand-inked-style chart of one zone from eq_journey.json + Brewall map files."""
import json, os, sys, math, html, re
from collections import Counter
from datetime import datetime
import build_viewer as bv

JOURNAL = None
SHOTS_DIR = None
SHOT_EXT = (".jpg", ".jpeg", ".png", ".webp", ".bmp")

def load_journal(path):
    """journal.md: '## <zone> - <YYYY-MM-DD>' headers, free text beneath. Returns {zone_lower: [(date, text)]}."""
    out = {}
    if not path or not os.path.exists(path): return out
    zone = date = None; buf = []
    def flush():
        if zone and buf: out.setdefault(zone.lower(), []).append((date, " ".join(l.strip() for l in buf if l.strip())))
    for line in open(path, encoding="utf-8"):
        m = re.match(r"^##\s*(.+?)\s*[-\u2013\u2014]\s*(\d{4}-\d{2}-\d{2})\s*$", line)
        if m: flush(); zone, date = m.group(1), m.group(2); buf = []
        elif zone is not None: buf.append(line)
    flush(); return out

def norm(name): return re.sub(r"[^a-z0-9]", "", name.lower())

def find_shots(zone, short):
    """Screenshots for this zone: files in SHOTS_DIR/<zone name or short name>/, with their capture time (file mtime)."""
    if not SHOTS_DIR or not os.path.isdir(SHOTS_DIR): return []
    out = []
    for folder in os.listdir(SHOTS_DIR):
        if norm(folder) not in (norm(zone), norm(short)): continue
        fdir = os.path.join(SHOTS_DIR, folder)
        for f in sorted(os.listdir(fdir)):
            if f.lower().endswith(SHOT_EXT):
                p = os.path.join(fdir, f)
                out.append({"file": f, "folder": folder, "ts": datetime.fromtimestamp(os.path.getmtime(p))})
    return out

DUNGEON = ("castle","tomb","lair","ruins","labyrinth","keep","chardok","sebilis","guk","caverns","crypt","mistmoore","befallen","unrest","nagafen","permafrost","hole","cazic","kedge","tower")
CITY = ("felwithe","halas","bazaar","thurgadin","kael","skyshrine","freeport","qeynos","kaladim","cabilis","erudin","neriak","oggok","grobb","rivervale","ak'anon","akanon","kelethin","knowledge","nexus","shadow haven")

def zone_kind(zone):
    n = zone.lower()
    if any(k in n for k in CITY): return "city"
    if any(k in n for k in DUNGEON): return "dungeon"
    return "wild"

def emblem(kind, x, y, ink):
    """A small line-drawn emblem for the cartouche: an arched gate, a tower, or peaks and sun."""
    if kind == "dungeon":
        return f'''<g transform="translate({x},{y})" fill="none" stroke="{ink}" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M4,44 L4,22 A18,18 0 0 1 40,22 L40,44"/><path d="M10,44 L10,24 A12,12 0 0 1 34,24 L34,44"/>
  <path d="M0,44 L44,44"/><path d="M22,30 L22,44"/><path d="M14,18 L16,12 M22,14 L22,8 M30,18 L28,12"/></g>'''
    if kind == "city":
        return f'''<g transform="translate({x},{y})" fill="none" stroke="{ink}" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M10,44 L10,14 L14,14 L14,10 L18,10 L18,14 L22,14 L22,10 L26,10 L26,14 L30,14 L30,10 L34,10 L34,14 L38,14 L38,44"/>
  <path d="M20,44 L20,32 A4,4 0 0 1 28,32 L28,44"/><path d="M2,44 L46,44"/><path d="M24,10 L24,2 L32,5 L24,8"/></g>'''
    return f'''<g transform="translate({x},{y})" fill="none" stroke="{ink}" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M0,44 L14,18 L22,30 L28,22 L44,44 Z"/><path d="M14,18 L18,26 L22,30"/><circle cx="36" cy="10" r="5"/>
  <path d="M36,1 L36,3 M36,17 L36,19 M27,10 L29,10 M43,10 L45,10 M30,4 L31,5 M41,15 L42,16 M30,16 L31,15 M41,5 L42,4"/></g>'''

def corner(x, y, sx, sy, ink):
    """A small curl in a corner of the border; sx, sy flip it into place."""
    return f'<g transform="translate({x},{y}) scale({sx},{sy})" fill="none" stroke="{ink}" stroke-width=".9" stroke-linecap="round" opacity=".8"><path d="M0,22 C0,8 8,0 22,0"/><path d="M0,34 C0,14 14,0 34,0"/><path d="M6,28 C10,16 16,10 28,6"/><circle cx="16" cy="16" r="1.6" fill="{ink}" stroke="none"/></g>'

def wrap(text, width=95):
    words, lines, cur = text.split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 > width and cur: lines.append(cur); cur = w
        else: cur = (cur + " " + w).strip()
    if cur: lines.append(cur)
    return lines

def build(short, journey, maps, out, journal=None):
    d = json.load(open(journey, encoding="utf-8", errors="replace")); bv.load_families(os.path.join(os.path.dirname(journey), "mob_families.json"))
    visits = [v for v in d["visits"] if v["zone_short"] == short]
    zone = visits[0]["zone"]; char = d["character"]
    lines = bv.parse_lines(os.path.join(maps, f"{short}.txt")); pts = bv.parse_points(os.path.join(maps, f"{short}_1.txt"))
    if not lines:
        print(f"  {short}.txt has no map lines; skipping its chart"); return
    trail, events, visit_days = [], [], []
    for v in visits:
        visit_days.append(v["entered"][:10])
        prev = None
        for p in v["trail"]:
            q = {"ts": p["t"], "p": bv.M(p["loc"])}
            if prev is None and trail: q["gap"] = True          # a new visit never joins to the previous one's last reading
            q["visit"] = len(visit_days); q["date"] = v["entered"][:10]
            if prev:
                dt = (datetime.fromisoformat(p["t"]) - datetime.fromisoformat(prev["ts"])).total_seconds()
                dd = math.dist(q["p"][:2], prev["p"][:2])
                if dt > 180 or dd > max(400, 130*dt): q["gap"] = True          # a port, or faster than any run: nothing drawn
                elif dd > 100 and dt > 4: q["inferred"] = True                # a run with no reading in between: drawn faint
            trail.append(q); prev = q
        for e in v["events"]:
            if not e["loc"] or e["stale"]: continue
            if e["type"] == "kill" and not (e.get("team") or e.get("named")): continue
            events.append({**e, "p": bv.M(e["loc"])})
    xs = [l[i] for l in lines for i in (0,3)]; ys = [l[i] for l in lines for i in (1,4)]
    zs = [l[i] for l in lines for i in (2,5)]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys); z0, z1 = min(zs), max(zs)
    notes_count = sum(len(v) for k, v in (journal or {}).items() if k in (zone.lower(), short.lower()))
    TOP = 110 + (0 if not notes_count else 30 + 60*min(3, notes_count))
    PAD = 150; sc = min(1.0, 1500/(x1-x0), 1900/(y1-y0)); W = (x1-x0)*sc + 2*PAD; H = (y1-y0)*sc + 2*PAD + TOP
    X = lambda x: (x - x0)*sc + PAD; Y = lambda y: (y - y0)*sc + PAD + TOP
    ink = "#3a2c1f"
    o = []
    labels = []   # deferred text: [x, y, text, attrs, fontsize]
    def L(x, y, text, attrs, fs): labels.append([x, y, text, attrs, fs])
    def flush_labels():
        placed = []
        for lab in sorted(labels, key=lambda l: -l[4]):
            x, y, text, attrs, fs = lab; w = len(text)*fs*0.5; h = fs*1.1
            for tries in range(8):
                box = (x, y-h, x+w, y+2)
                if not any(not (box[2] < b[0] or box[0] > b[2] or box[3] < b[1] or box[1] > b[3]) for b in placed): break
                y += h * (1 if tries % 2 == 0 else -1) * (tries//2 + 1)
            placed.append((x, y-h, x+w, y+2))
            o.append(f'<text x="{x:.1f}" y="{y:.1f}" font-size="{fs}" {attrs}>{html.escape(text)}</text>')
    o.append(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W:.0f} {H:.0f}" preserveAspectRatio="xMidYMid meet" font-family="\'EB Garamond\',Georgia,serif">')
    o.append('''<defs>
  <radialGradient id="vig" cx="50%" cy="45%" r="75%"><stop offset="60%" stop-color="#ecdfc4" stop-opacity="0"/><stop offset="100%" stop-color="#b89f74" stop-opacity=".45"/></radialGradient>
  <filter id="soft" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="18"/></filter>
  <filter id="soft2" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="9"/></filter>
  <pattern id="hatch" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(35)"><line x1="0" y1="0" x2="0" y2="6" stroke="#3a2c1f" stroke-width=".5" opacity=".28"/></pattern>
</defs>''')
    o.append(f'<rect width="{W:.0f}" height="{H:.0f}" fill="#ecdfc4"/><rect width="{W:.0f}" height="{H:.0f}" fill="url(#vig)"/>')
    o.append(f'<rect x="22" y="22" width="{W-44:.0f}" height="{H-44:.0f}" fill="none" stroke="{ink}" stroke-width="1.4" opacity=".8"/><rect x="30" y="30" width="{W-60:.0f}" height="{H-60:.0f}" fill="none" stroke="{ink}" stroke-width=".5" opacity=".8"/>')
    o += [corner(40, 40, 1, 1, ink), corner(W-40, 40, -1, 1, ink), corner(40, H-40, 1, -1, ink), corner(W-40, H-40, -1, -1, ink)]
    # explored wash: wide soft stroke under the route, warmer where fights were
    def path(pts_, inferred=False):
        """Solid route: skip gap and inferred segments. inferred=True: only the inferred segments."""
        s = ''; pen = False
        for i, p in enumerate(pts_):
            brk = p.get("gap") or (bool(p.get("inferred")) != inferred)
            if brk: pen = False
            if inferred and p.get("inferred") and i > 0 and not p.get("gap"):
                q = pts_[i-1]; s += f'M{X(q["p"][0]):.1f},{Y(q["p"][1]):.1f} L{X(p["p"][0]):.1f},{Y(p["p"][1]):.1f} '
                continue
            if inferred: continue
            s += ('L' if pen else 'M') + f'{X(p["p"][0]):.1f},{Y(p["p"][1]):.1f} '; pen = True
        return s
    if trail:
        o.append(f'<path d="{path(trail)}" fill="none" stroke="#cdb894" stroke-width="{max(40, 120*sc):.0f}" stroke-linecap="round" stroke-linejoin="round" filter="url(#soft)" opacity=".75"/>')
        o.append(f'<path d="{path(trail)}" fill="none" stroke="url(#hatch)" stroke-width="{max(32, 100*sc):.0f}" stroke-linecap="round" stroke-linejoin="round" opacity=".35"/>')
    for e in events:
        if e["type"] == "kill":
            o.append(f'<circle cx="{X(e["p"][0]):.1f}" cy="{Y(e["p"][1]):.1f}" r="26" fill="#a8623f" opacity=".035" filter="url(#soft2)"/>')
    # walls, lighter ink for lower floors, drawn low-to-high
    zspan = max(1, z1 - z0)
    for l in sorted(lines, key=lambda l: (l[2]+l[5])/2):
        k = ((l[2]+l[5])/2 - z0)/zspan
        op = 0.5 + 0.5*k; w = 0.8 + 0.5*k
        col = ink if (l[6]|l[7]|l[8]) == 0 else "#6b4d2f"
        o.append(f'<line x1="{X(l[0]):.1f}" y1="{Y(l[1]):.1f}" x2="{X(l[3]):.1f}" y2="{Y(l[4]):.1f}" stroke="{col}" stroke-width="{w:.2f}" opacity="{op:.2f}" stroke-linecap="round"/>')
    # Brewall spots: small italic labels, only landmarks (not merchants/quest npcs by name)
    for x, y, z, r, g, b, name in pts:
        if name.startswith(("to ", "Succor")) or (r, g, b) == (240, 240, 240) or name.endswith("(Hunter)") or name.endswith("(Raid)"):
            nm = name.replace("(Hunter)", "").replace("(Raid)", "").replace("to ", "To ").strip()
            o.append(f'<circle cx="{X(x):.1f}" cy="{Y(y):.1f}" r="2" fill="{ink}" opacity=".7"/>')
            L(X(x)+6, Y(y)+4, nm, f'font-style="italic" fill="{ink}" opacity=".75"', 13)
    # route
    if trail:
        newest = max(t["date"] for t in trail)
        def age_style(date):
            days = (datetime.fromisoformat(newest) - datetime.fromisoformat(date)).days
            k = min(1.0, days / 30)                      # 0 = last visit, 1 = a month or more ago
            r, g, b = (int(122 + (150-122)*k), int(46 + (110-46)*k), int(30 + (70-30)*k))   # red-brown -> faded sepia
            return f"#{r:02x}{g:02x}{b:02x}", 0.9 - 0.5*k
        for vi in sorted(set(t["visit"] for t in trail)):
            seg = [t for t in trail if t["visit"] == vi]
            col, op = age_style(seg[0]["date"])
            o.append(f'<g><title>{html.escape(datetime.fromisoformat(seg[0]["date"]).strftime("%d %B %Y").lstrip("0"))}, {len(seg)} readings</title>')
            o.append(f'<path d="{path(seg, inferred=True)}" fill="none" stroke="{col}" stroke-width="1.1" stroke-dasharray="2 7" stroke-linecap="round" opacity="{op*0.5:.2f}"/>')
            o.append(f'<path d="{path(seg)}" fill="none" stroke="{col}" stroke-width="1.5" stroke-dasharray="7 5" stroke-linecap="round" stroke-linejoin="round" opacity="{op:.2f}"/></g>')
        o.append(f'<circle cx="{X(trail[0]["p"][0]):.1f}" cy="{Y(trail[0]["p"][1]):.1f}" r="4" fill="#ecdfc4" stroke="#7a2e1e" stroke-width="1.5"/>')
        o.append(f'<circle cx="{X(trail[-1]["p"][0]):.1f}" cy="{Y(trail[-1]["p"][1]):.1f}" r="4" fill="#7a2e1e"/>')
    # kills as engraved crossed blades, clustered
    def cluster(list_, R=26):
        cs = []
        for e in list_:
            c = next((c for c in cs if math.dist(c["p"], e["p"][:2]) < R), None)
            if c: c["n"] += 1; c["items"].append(e)
            else: cs.append({"p": e["p"][:2], "n": 1, "items": [e]})
        return cs
    def when(e): return datetime.fromisoformat(e["t"]).strftime("%d %b %Y, %I:%M %p").lstrip("0").replace(" 0", " ")
    def tip(text): return f'<title>{html.escape(text)}</title>'
    for c in cluster([e for e in events if e["type"] == "kill" and not e.get("named")]):
        cx, cy = X(c["p"][0]), Y(c["p"][1]); s = 5 + min(4, c["n"]//4)
        names = Counter(i["mob"] for i in c["items"]); summary = ", ".join(f"{k}{' ×'+str(v) if v>1 else ''}" for k, v in names.most_common(4))
        ttl = tip(f"{summary} — {when(c['items'][0])}" if c["n"] == 1 else f"{c['n']} kills here: {summary}. {when(c['items'][0])[:11]} to {when(c['items'][-1])}")
        o.append(f'<g stroke="{ink}" stroke-width="1.1" stroke-linecap="round" opacity=".85">{ttl}<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{s+4}" fill="transparent" stroke="none"/><line x1="{cx-s:.1f}" y1="{cy-s:.1f}" x2="{cx+s:.1f}" y2="{cy+s:.1f}"/><line x1="{cx+s:.1f}" y1="{cy-s:.1f}" x2="{cx-s:.1f}" y2="{cy+s:.1f}"/></g>')
        if c["n"] > 1: L(cx+s+3, cy-s+2, str(c["n"]), f'fill="{ink}" opacity=".8"', 11)
    # named: an eight-point star with small-caps label
    named_cl = []
    for e in [e for e in events if e["type"] == "kill" and e.get("named")]:
        c = next((c for c in named_cl if c["mob"] == e["mob"] and math.dist(c["p"], e["p"][:2]) < 60), None)
        if c: c["n"] += 1; c["items"].append(e)
        else: named_cl.append({"mob": e["mob"], "p": e["p"][:2], "n": 1, "items": [e]})
    for e in named_cl:
        cx, cy = X(e["p"][0]), Y(e["p"][1])
        star = ' '.join(f'{cx+math.cos(a)*(11 if i%2==0 else 4.5):.1f},{cy+math.sin(a)*(11 if i%2==0 else 4.5):.1f}' for i,a in enumerate([k*math.pi/8 for k in range(16)]))
        ttl = tip("; ".join(f"{e['mob']}, slain by {e['by']}, {when(e)}" for e in e["items"]))
        o.append(f'<g>{ttl}<polygon points="{star}" fill="#ecdfc4" stroke="#7a2e1e" stroke-width="1.4"/><circle cx="{cx:.1f}" cy="{cy:.1f}" r="2.2" fill="#7a2e1e"/></g>')
        L(cx+15, cy+5, e["mob"] + (" ×" + str(e["n"]) if e["n"] > 1 else ""), 'font-variant="small-caps" letter-spacing="1" fill="#7a2e1e"', 14)
    for e in [e for e in events if e["type"] == "level"]:
        cx, cy = X(e["p"][0]), Y(e["p"][1])
        lvl_tip = tip("Level " + str(e["level"]) + ", " + when(e))
        o.append(f'<g>{lvl_tip}<circle cx="{cx:.1f}" cy="{cy:.1f}" r="7" fill="none" stroke="{ink}" stroke-width="1.2"/><circle cx="{cx:.1f}" cy="{cy:.1f}" r="2.5" fill="{ink}"/></g>')
        L(cx+11, cy+4, f'Level {e["level"]}', f'font-variant="small-caps" letter-spacing="1" fill="{ink}" opacity=".85"', 12)
    death_cl = []
    for e in [e for e in events if e["type"] == "death"]:
        c = next((c for c in death_cl if math.dist(c["p"], e["p"][:2]) < 45), None)
        if c: c["items"].append(e)
        else: death_cl.append({"p": e["p"][:2], "items": [e]})
    for c in death_cl:
        cx, cy = X(c["p"][0]), Y(c["p"][1]); n = len(c["items"])
        ttl = tip("; ".join(f"{i['who']} fell to {i['by']}, {when(i)}" for i in c["items"][:6]) + (f"; and {n-6} more" if n > 6 else ""))
        o.append(f'<g stroke="{ink}" stroke-width="1.3" stroke-linecap="round">{ttl}<circle cx="{cx:.1f}" cy="{cy:.1f}" r="10" fill="transparent" stroke="none"/><line x1="{cx:.1f}" y1="{cy-8:.1f}" x2="{cx:.1f}" y2="{cy+8:.1f}"/><line x1="{cx-5:.1f}" y1="{cy-3:.1f}" x2="{cx+5:.1f}" y2="{cy-3:.1f}"/></g>')
        if n == 1:
            txt = f'{c["items"][0]["who"]} fell'
        else:
            by = max(set(e["by"] for e in c["items"]), key=[e["by"] for e in c["items"]].count)
            txt = f'{n} fell here to {by}'
        L(cx+9, cy+4, txt, f'font-style="italic" fill="{ink}" opacity=".85"', 12)
    # screenshots, pinned to the nearest reading in time (within ten minutes)
    shots = find_shots(zone, short); pinned = []
    if shots and trail:
        times = [(datetime.fromisoformat(t["ts"]), t) for t in trail]
        for sh in shots:
            best = min(times, key=lambda x: abs((x[0] - sh["ts"]).total_seconds()))
            if abs((best[0] - sh["ts"]).total_seconds()) <= 600:
                pinned.append((sh, best[1]))
    rel = os.path.relpath(SHOTS_DIR, out).replace("\\", "/") if SHOTS_DIR else ''
    stack = {}
    for sh, t in pinned:
        cx, cy = X(t["p"][0]), Y(t["p"][1]); k = (round(cx/40), round(cy/40)); stack[k] = stack.get(k, 0) + 1
        dx = 12 + (stack[k]-1)*10; dy = -60 - (stack[k]-1)*8; w, h = 72, 44
        href = html.escape(f'{rel}/{sh["folder"]}/{sh["file"]}', quote=True)
        when_txt = sh["ts"].strftime("%d %b %Y, %I:%M %p").lstrip("0")
        o.append(f'<line x1="{cx:.1f}" y1="{cy:.1f}" x2="{cx+dx+4:.1f}" y2="{cy+dy+h:.1f}" stroke="{ink}" stroke-width=".8" opacity=".6"/>')
        o.append(f'<a href="{href}" target="_blank"><g class="shot"><title>{html.escape(sh["file"])}, {when_txt}. Click to open.</title>'
                 f'<rect x="{cx+dx:.1f}" y="{cy+dy:.1f}" width="{w+8}" height="{h+8}" fill="#f3ead6" stroke="{ink}" stroke-width=".9" transform="rotate(-4 {cx+dx:.1f} {cy+dy:.1f})"/>'
                 f'<image href="{href}" x="{cx+dx+4:.1f}" y="{cy+dy+4:.1f}" width="{w}" height="{h}" preserveAspectRatio="xMidYMid slice" transform="rotate(-4 {cx+dx:.1f} {cy+dy:.1f})"/></g></a>')
    if shots and not pinned:
        o.append(f'<text x="{PAD-70}" y="{H-100}" font-size="13" font-style="italic" fill="{ink}" opacity=".6">{len(shots)} screenshot{"s" if len(shots)>1 else ""} in the folder could not be matched to a reading within ten minutes.</text>')
    flush_labels()
    # cartouche
    kills = sum(1 for e in events if e["type"]=="kill" and e.get("team")); named = [e["mob"] for e in events if e["type"]=="kill" and e.get("named")]
    dates = sorted({v["entered"][:10] for v in visits if v["trail"]})
    when = datetime.fromisoformat(dates[0]).strftime("%d %B %Y").lstrip("0") if dates else ""
    # journal entries for this zone (matched by long name or map name), newest last, at most three
    notes = []
    for key, entries in (journal or {}).items():
        if key in (zone.lower(), short.lower()): notes += entries
    notes = sorted(notes)[-3:]
    ny = 92; parts = []
    for d_, text in notes:
        parts.append(f'<text x="58" y="{ny}" font-family="Cinzel,serif" font-size="10" letter-spacing="3" fill="{ink}" opacity=".6">{html.escape(datetime.fromisoformat(d_).strftime("%d %B %Y").lstrip("0").upper())}</text>'); ny += 18
        for ln in wrap(text):
            parts.append(f'<text x="58" y="{ny}" font-size="15" fill="{ink}" opacity=".9">{html.escape(ln)}</text>'); ny += 19
        ny += 6
    notes_svg = "\n".join(parts)
    o.append(f'''<g transform="translate({PAD-40:.0f},44)">
  {emblem(zone_kind(zone), -2, -6, ink)}
  <text x="58" font-family="Cinzel,serif" font-size="11" letter-spacing="4" fill="{ink}" opacity=".7">A CHART OF</text>
  <text x="58" y="34" font-family="Cinzel,serif" font-size="30" letter-spacing="1.5" fill="{ink}">{html.escape(zone.upper())}</text>
  <line x1="58" y1="46" x2="{58+min(420, len(zone)*19)}" y2="46" stroke="{ink}" stroke-width=".8"/>
  <text x="58" y="68" font-size="15" font-style="italic" fill="{ink}" opacity=".85">as walked by {html.escape(char)} and company, {when}. {len(trail)} readings, {kills} kills by the party{(', ' + ' &amp; '.join(html.escape(n) for n in sorted(set(named))) + ' slain') if 0 < len(set(named)) <= 3 else (f', {len(named)} named slain' if named else '')}{f", {len(pinned)} screenshot{'s' if len(pinned)>1 else ''}" if pinned else ''}.</text>
{notes_svg}
</g>''')
    # "here be": Brewall's named not yet slain here, tucked under the compass
    try:
        named_list = json.load(open(os.path.join(os.path.dirname(journey), "named_mobs.json"), encoding="utf-8")).get(short, [])
    except Exception:
        named_list = []
    slain = {n.lower() for n in named}
    unslain = [n for n in named_list if n.lower() not in slain]
    if unslain:
        shown = unslain[:6]; more = len(unslain) - len(shown)
        text = "Here be " + ", ".join(shown) + (f" and {more} more" if more > 0 else "") + ", yet unslain."
        ty = PAD + 130
        for ln in wrap(text, 34):
            o.append(f'<text x="{W - PAD + 30:.0f}" y="{ty}" text-anchor="middle" font-size="12.5" font-style="italic" fill="{ink}" opacity=".62">{html.escape(ln)}</text>'); ty += 16
    # compass
    cx, cy = W - PAD + 30, PAD + 60
    o.append(f'''<g transform="translate({cx:.0f},{cy:.0f})" stroke="{ink}" fill="{ink}">
  <circle r="30" fill="none" stroke-width=".6" opacity=".6"/><circle r="22" fill="none" stroke-width=".4" opacity=".5"/>
  <polygon points="0,-40 5,0 0,6 -5,0" stroke="none"/><polygon points="0,40 4,0 0,-4 -4,0" stroke="none" opacity=".45"/>
  <polygon points="-40,0 0,4 4,0 0,-4" stroke="none" opacity=".45"/><polygon points="40,0 0,4 -4,0 0,-4" stroke="none" opacity=".45"/>
  <text y="-46" text-anchor="middle" font-family="Cinzel,serif" font-size="13" stroke="none">N</text>
</g>''')
    # legend + scale
    lx, ly = PAD - 70, H - 70
    o.append(f'''<g transform="translate({lx:.0f},{ly:.0f})" font-size="13" fill="{ink}">
  <line x1="0" y1="0" x2="{200*sc:.0f}" y2="0" stroke="{ink}" stroke-width="1"/><line x1="0" y1="-4" x2="0" y2="4" stroke="{ink}"/><line x1="{200*sc:.0f}" y1="-4" x2="{200*sc:.0f}" y2="4" stroke="{ink}"/><text x="{100*sc:.0f}" y="-8" text-anchor="middle" font-style="italic">200 paces</text>
  <g transform="translate(260,-4)"><path d="M0,0 L24,0" stroke="#7a2e1e" stroke-width="1.5" stroke-dasharray="7 5"/><text x="32" y="4">the route</text></g>
  <g transform="translate(560,-4)"><g stroke="{ink}" stroke-width="1.1"><line x1="0" y1="-5" x2="10" y2="5"/><line x1="10" y1="-5" x2="0" y2="5"/></g><text x="18" y="4">a kill (number if several)</text></g>
  <g transform="translate(770,-4)"><polygon points="8,-10 10,-3 17,-3 11,1 13,8 8,4 3,8 5,1 -1,-3 6,-3" fill="#ecdfc4" stroke="#7a2e1e" stroke-width="1.2"/><text x="24" y="4">a named one slain</text></g>
  <g transform="translate(940,-4)"><circle cx="6" r="6" fill="none" stroke="{ink}" stroke-width="1.2"/><circle cx="6" r="2" fill="{ink}"/><text x="18" y="4">a level gained</text></g>
  <text y="30" font-style="italic" opacity=".7">Darker ink marks the higher halls; the shaded ground is where the party walked, and the warmer stains where it fought. The route fades with age: the latest visit is darkest. Rest the mouse on any mark to read it.</text>
</g>''')
    o.append('</svg>')
    if trail:
        fx = sum(X(t["p"][0]) for t in trail)/len(trail); fy = sum(Y(t["p"][1]) for t in trail)/len(trail)
    else:
        fx, fy = W/2, H/2
    page = f'''<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>A chart of {html.escape(zone)}</title>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;600&family=EB+Garamond:ital,wght@0,400;0,500;1,400&display=swap" rel="stylesheet">
<style>html,body{{margin:0;height:100%;background:#1b1610;overflow:hidden}}
svg{{position:fixed;inset:0;width:100vw;height:100vh;cursor:grab;user-select:none;-webkit-user-select:none}} svg text{{pointer-events:none}} .shot{{cursor:pointer}} .shot:hover rect{{stroke-width:2}} svg:active{{cursor:grabbing}}
a.back{{position:fixed;top:14px;left:18px;color:#c9b48e;font:14px "EB Garamond",serif;text-decoration:none;background:rgba(27,22,16,.7);padding:6px 10px;border-radius:3px}}
#z{{position:fixed;right:18px;bottom:18px;display:flex;gap:6px}}
#z button{{font:14px "EB Garamond",serif;color:#e9dcc0;background:rgba(27,22,16,.75);border:1px solid #6b5a45;border-radius:3px;padding:6px 12px;cursor:pointer}}
#z button:hover{{background:rgba(58,44,31,.9)}}
#info{{position:fixed;display:none;max-width:340px;padding:10px 14px;background:linear-gradient(160deg,#e9dcc0,#dccbaa);color:#2a2118;border:1px solid #b89b6a;border-radius:3px;font:15px/1.45 "EB Garamond",Georgia,serif;box-shadow:0 10px 26px rgba(0,0,0,.45);pointer-events:none;z-index:5}}
svg [data-info]{{cursor:pointer}}</style></head>
<body><a class="back" href="index.html">Return to the atlas</a>{''.join(o)}
<div id="z"><button id="zfit">Whole chart</button><button id="zout">−</button><button id="zin">+</button></div>
<div id="info"></div>
<script>
const svg=document.querySelector('svg');const vb0=svg.getAttribute('viewBox').split(' ').map(Number);let vb=[...vb0],drag=null;
const focus={{x:{fx:.0f},y:{fy:.0f}}};
function apply(){{svg.setAttribute('viewBox',vb.join(' '))}}
function fitAspect(w){{const r=svg.getBoundingClientRect();vb[2]=w;vb[3]=w*r.height/r.width}}
function start(){{const r=svg.getBoundingClientRect();const w=Math.min(vb0[2],Math.max(900,vb0[2]*0.6));fitAspect(w);vb[0]=focus.x-vb[2]/2;vb[1]=focus.y-vb[3]/2;apply()}}
function fit(){{const r=svg.getBoundingClientRect();const w=Math.max(vb0[2],vb0[3]*r.width/r.height)*1.04;fitAspect(w);vb[0]=vb0[2]/2-vb[2]/2;vb[1]=vb0[3]/2-vb[3]/2;apply()}}
function zoom(k,cx,cy){{const r=svg.getBoundingClientRect();const px=vb[0]+cx/r.width*vb[2],py=vb[1]+cy/r.height*vb[3];const w=Math.min(vb0[2]*2,Math.max(300,vb[2]*k));fitAspect(w);vb[0]=px-cx/r.width*vb[2];vb[1]=py-cy/r.height*vb[3];apply()}}
svg.addEventListener('wheel',e=>{{e.preventDefault();const r=svg.getBoundingClientRect();zoom(Math.exp(e.deltaY*0.0012),e.clientX-r.left,e.clientY-r.top)}},{{passive:false}});
const info=document.getElementById('info');
function showInfo(el,x,y){{const t=el.querySelector('title');if(!t)return false;info.textContent=t.textContent;info.style.display='block';const r=info.getBoundingClientRect();info.style.left=Math.min(x+14,innerWidth-r.width-12)+'px';info.style.top=Math.min(y+14,innerHeight-r.height-12)+'px';return true}}
svg.addEventListener('pointerdown',e=>{{if(e.target.closest('a'))return;drag={{x:e.clientX,y:e.clientY,sx:e.clientX,sy:e.clientY,target:e.target}};svg.setPointerCapture(e.pointerId)}});
svg.addEventListener('pointerup',e=>{{if(drag&&Math.hypot(e.clientX-drag.sx,e.clientY-drag.sy)<4){{const el=drag.target;let shown=false;for(let n=el;n&&n!==svg;n=n.parentElement){{if(n.querySelector&&n.querySelector(':scope>title')){{shown=showInfo(n,e.clientX,e.clientY);break}}}}if(!shown)info.style.display='none'}}drag=null}});
svg.addEventListener('pointermove',e=>{{if(drag&&Math.hypot(e.clientX-drag.sx,e.clientY-drag.sy)>=4)info.style.display='none'}});
svg.addEventListener('pointermove',e=>{{if(!drag)return;const r=svg.getBoundingClientRect();vb[0]-=(e.clientX-drag.x)*vb[2]/r.width;vb[1]-=(e.clientY-drag.y)*vb[3]/r.height;drag={{x:e.clientX,y:e.clientY}};apply()}});
svg.addEventListener('dblclick',start);
document.getElementById('zfit').onclick=fit;document.getElementById('zin').onclick=()=>{{const r=svg.getBoundingClientRect();zoom(0.7,r.width/2,r.height/2)}};document.getElementById('zout').onclick=()=>{{const r=svg.getBoundingClientRect();zoom(1.4,r.width/2,r.height/2)}};
addEventListener('resize',()=>{{fitAspect(vb[2]);apply()}});
start();
</script></body></html>'''
    with open(os.path.join(out, f"{short}_chart.html"), "w", encoding="utf-8") as f: f.write(page)
    print(short, len(lines), len(trail), len(events), f"{W:.0f}x{H:.0f}")

if __name__ == "__main__":
    build(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
