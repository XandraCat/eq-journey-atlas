# EverQuest Journey Atlas

Turns your EverQuest log into hand-inked charts of every zone you've walked: your route, the
party's kills, the named you've slain, deaths and level-ups, with your own journal notes in the
margins. It also draws your route onto the in-game map, as its own layer you can switch on and off.

It reads only your log file and the map files already in your EverQuest folder. It doesn't touch
the game, needs no add-ons, and sends nothing anywhere unless you turn publishing on.

---

## What you need

- **Windows** with **Python 3.9 or newer.** Get it from [python.org](https://www.python.org/downloads/).
  During install, tick **"Add python.exe to PATH"**. Nothing else to install.
- **Brewall's maps** in your EverQuest `maps\Brewall` folder. The charts are drawn over them.
  Get them from [Brewall's site](https://www.eqmaps.info/).

## Setup (once)

1. **Unzip this folder** anywhere you like, for example `C:\EQ Atlas`.
2. **Turn on logging** in game: type `/log on` once on each character you want charted.
3. **Use `/loc` often.** It's the only position the log records, so the atlas can only draw where
   you were when you typed it. Bind it to a key you press all the time; many people put it on
   their forward key with a hotkey or social. More `/loc` means better routes.
4. **Optional: open `config.json`** in Notepad. Most people only fill in `team`, the characters
   you play together:
   ```json
   "team": ["Mychar", "Myboxone", "Myboxtwo"],
   ```
   Leave it empty if you play one character. If the atlas can't find EverQuest by itself, set
   `eq_dir` to the folder with `eqgame.exe` in it, using double backslashes:
   `"C:\\Users\\Public\\Daybreak Game Company\\Installed Games\\EverQuest"`.

## Using it

- **`atlas_live.bat`**: double-click it before you play and leave the window open. The atlas
  updates every 5 minutes.
- **`update_atlas.bat`**: updates once, whenever you like.

Then open **`journey\index.html`** in your browser. Refresh the page (F5) to see the latest.

**In game**, open the map window: your route is the third layer checkbox. The map only reloads
when you zone, so new lines appear after your next zone change.

## The pages

| Page | What's on it |
|---|---|
| `index.html` | The atlas: a card for every charted zone, grouped by continent, and a table of the numbers. |
| `<zone>_chart.html` | One zone's chart. Drag to move, scroll to zoom, click any mark to read it. Routes fade with age; the latest visit is darkest. |
| `sessions.html` | The journey day by day, with your journal notes on their dates. |
| `bestiary.html` | Every named slain: where, how often and by whom. |
| `fallen.html` | Every death of the party. |

## Making it yours

- **`journal.md`**: your notes. Write a heading `## <zone> - <YYYY-MM-DD>` and text beneath it;
  the three newest notes for a zone appear on its chart.
- **`Atlas Screenshots\`**: a folder for each zone you've been to appears here. Drop a screenshot
  into its zone's folder and it gets pinned to the chart where you were when you took it (within
  ten minutes). No renaming needed.
- **`pins\`**: your own points of interest on the in-game map (vendors, camps, quest NPCs).
  See `pins\README.txt`.
- **`journey\named_mobs.json`**: which mobs count as named and get a star. It comes filled in for
  over a hundred zones. New zones are filled in from Brewall's map markers the first time you
  enter them. After each run, the atlas lists capitalised mobs it wasn't sure about; add the
  genuinely rare ones.
- **`zone_names.json`**: if a zone says "no map yet" but you do have its map file, the log's zone
  name and the file name don't match. Add a line here, then run `python fix_zone_names.py` once.

## Publishing your atlas (optional)

The atlas can keep a public copy of itself on a free website (GitHub Pages), updated while you
play: every 30 minutes, plus once more about 10 minutes after you stop. The public copy:

- keeps your own characters' names (everyone in `team`, plus any you list in `show_names`);
- shows **every other player as "the raid"**, in charts, the bestiary, sessions and your journal
  notes, so you never publish anyone's name without asking;
- leaves out loot entirely.

You can see exactly what it will publish before it goes anywhere: run `python publish.py --preview`
and open `public\atlas\index.html`.

To set it up:

1. Make a free account at [github.com](https://github.com) and create a **public repository**,
   for example `eq-atlas`. Tick "Add a README file" so it isn't empty.
2. Make a token: GitHub → Settings → Developer settings → **Fine-grained tokens** → Generate new
   token. Under *Repository access*, choose *Only select repositories* and pick your atlas
   repository. Under *Permissions*, set **Contents: Read and write** and **Pages: Read and write**.
   Copy the token.
3. Paste the token into a new text file called **`github_token.txt`** in this folder. Keep it
   private: it's the key to that one repository. (Never share this folder's copy of it.)
4. In `config.json`, under `publish`, set `"enabled": true` and
   `"github_repo": "YourGitHubName/eq-atlas"`.
5. Run `update_atlas.bat` once. The first publish uploads everything and can take a few minutes.
   After that, only what changed is sent. Your atlas appears at
   `https://YourGitHubName.github.io/eq-atlas/atlas/` within a minute or two.

**Your own domain:** set `"custom_domain": "yourdomain.com"` and, at your domain registrar, add
the DNS records GitHub lists under *Settings → Pages → Custom domain*.

**A front page:** anything you put in a `site` folder next to `atlas.py` is published alongside
the atlas, so `site\index.html` becomes your home page and the atlas sits at `/atlas/`.

Each publish, and any problem, is noted in `publish_log.txt`.

## How it reads the log

- `Your Location is Y, X, Z` from `/loc` is the only position data. Every kill, death and
  level-up is timestamped, and each is pinned to the nearest reading in time. If the nearest is
  more than two minutes away, it's counted but not placed on the chart.
- Map files store `x = -X, y = -Y`. The atlas does the conversion.
- The route breaks where readings are far apart in time, or where you moved faster than anyone
  can run (a port). A stretch covered without a reading in between is drawn as a faint dotted
  line.
- The party's kills are those by names in `team` or their pets. Named kills count whoever lands
  the blow, so raid bosses always show.

## Files

```
atlas.py            the one command (the .bat files run it)
eq_log_parser.py    log -> journey + in-game layer files
build_viewer.py     the index page, zone by zone
build_chart.py      the inked chart itself
build_pages.py      sessions, bestiary, fallen
publish.py          the optional public copy and upload
config.json  zone_names.json  journal.md  pins\
journey\            your atlas: open index.html
backups\            recent copies of your journey data
```

Requires Python 3.9+. No other packages.

## Credits

Zone outlines and landmarks come from **Brewall's EverQuest maps** ([eqmaps.info](https://www.eqmaps.info/)),
read from your own install; they are not included here. EverQuest is a trademark of Daybreak Game Company.
This is a fan project with no connection to Daybreak.
