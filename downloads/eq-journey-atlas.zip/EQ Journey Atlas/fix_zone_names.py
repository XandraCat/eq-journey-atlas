"""Re-derive every visit's map-file name from zone_names.json.
Run this once after editing zone_names.json: python fix_zone_names.py
(Visits keep the map name they were given when first parsed; this refreshes them.)"""
import json, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import eq_log_parser as p
p.load_zone_names(os.path.join(HERE, "zone_names.json"))
jpath = os.path.join(HERE, "journey", "eq_journey.json")
d = json.load(open(jpath, encoding="utf-8"))
changed = {}
for v in d["visits"]:
    if not v.get("zone"): continue
    new = p.short_zone(v["zone"])
    if new != v.get("zone_short"):
        changed[v["zone"]] = (v.get("zone_short"), new); v["zone_short"] = new
json.dump(d, open(jpath, "w", encoding="utf-8"), indent=1)
if changed:
    for z, (a, b) in changed.items(): print(f"{z}: {a} -> {b}")
    print("Done. Run the atlas again to rebuild the charts.")
else:
    print("Nothing to change - every visit already matches zone_names.json.")
