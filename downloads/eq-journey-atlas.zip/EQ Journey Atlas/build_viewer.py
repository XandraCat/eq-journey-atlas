#!/usr/bin/env python3
"""
Build the journey atlas from eq_journey.json + Brewall map files.

    python build_viewer.py --journey journey/eq_journey.json --maps maps/ --out journey/

For every zone in the journey that has <short>.txt in --maps, writes <short>_wireframe.html.
Always writes index.html listing every zone visited (linked where a wireframe exists).
"""
import json, os, sys, argparse, html
from collections import defaultdict
from datetime import datetime, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
JOURNEY_PATH = None
TEAM = set()   # set by atlas.py from config.json
HOME_LINK = ""  # public site only: a link back to the site's front page

def parse_lines(path):
    out = []
    for raw in open(path, encoding="utf-8", errors="replace"):
        if not raw.startswith("L"): continue
        p = [s.strip() for s in raw.strip()[1:].split(",")]
        v = [round(float(x),1) for x in p[:6]] + [int(float(x)) for x in p[6:9]]
        out.append(v)
    return out

def parse_points(path):
    out = []
    if not os.path.exists(path): return out
    for raw in open(path, encoding="utf-8", errors="replace"):
        if not raw.startswith("P"): continue
        p = [s.strip() for s in raw.strip()[1:].split(",")]
        if p[7].startswith(("Original_Map", "Revised_Map", "http", "Return_of")): continue
        out.append([round(float(p[0]),1), round(float(p[1]),1), round(float(p[2]),1), int(p[3]), int(p[4]), int(p[5]), p[7].replace("_"," ")])
    return out

FAM = {"rules": [], "zone_default": {}}
def load_families(path):
    global FAM
    if os.path.exists(path): FAM = json.load(open(path, encoding="utf-8", errors="replace"))
def family(mob, zone_short):
    m = mob.lower()
    for kw, fam in FAM["rules"]:
        if kw in m: return fam
    return FAM["zone_default"].get(zone_short)

def M(loc):
    y, x, z = loc
    return [round(-x,1), round(-y,1), round(z,1)]

def hours(v):
    """Length of a visit. Ends at the zone change, unless the last reading or event was long before it
    (logged out in the zone, came back next day): then it ends ten minutes after the last activity."""
    last = max([p["t"] for p in v["trail"]] + [e["t"] for e in v["events"]] + [v["entered"]])
    end = datetime.fromisoformat(last) + timedelta(minutes=10)
    if v["left"]:
        end = min(end, datetime.fromisoformat(v["left"]))
    return max(0, (end - datetime.fromisoformat(v["entered"])).total_seconds()/3600)

def build_zone(short, visits, maps, out, char, template=None):
    """Chart one zone if its Brewall base map exists."""
    if not os.path.exists(os.path.join(maps, f"{short}.txt")): return False
    import build_chart
    build_chart.build(short, JOURNEY_PATH, maps, out, getattr(build_chart, "JOURNAL", None))
    return True

CONTINENT = {
 "Antonica": ["paw","commonlands","southro","northro","halas","everfrost","blackburrow","qeynos","freeport","freportw","freporte","freeporteast","freeportwest","freeportsewers","northernplainsofkarana","westernplainsofkarana","southernplainsofkarana","easternplainsofkarana","oasis","nektulos","lavastorm","kithicor","highpass","highkeep","rivervale","misty","befallen","innothule","feerrott","cazicthule","rathemtn","lakerathe","guktop","gukbottom","soldunga","soldungb","permafrost","westkarana","northkarana","eastkarana","southkarana","qeytoqrg","oot","neriaka","neriakb","neriakc","grobb","oggok","runnyeye","beholder","kerraridge","erudnext","erudnint","tox","paineel","hole","kedge","cauldron"],
 "Faydwer": ["felwithea","felwitheb","gfaydark","lfaydark","mistmoore","unrest","crushbone","butcher","kaladima","kaladimb","akanon","steamfont","cauldron","kedge"],
 "Kunark": ["karnor","dreadlands","burningwood","skyfire","chardok","emeraldjungle","trakanon","sebilis","fieldofbone","overthere","frontiermtns","warslikswood","lakeofillomen","firiona","cabeast","cabwest","kurn","dalnir","charasis","citymist","timorous","veeshan","swampofnohope","droga","nurga"],
 "Velious": ["kael","skyshrine","wakening","greatdivide","eastwastes","westwastes","sleeper","velketor","thurgadina","thurgadinb","crystal","frozenshadow","iceclad","cobaltscar","sirens","necropolis","templeveeshan","growthplane","mischiefplane"],
 "The Planes": ["hateplane","fearplane","airplane"],
 "Luclin": ["bazaar","nexus","shadowhaven","echo","thedeep","netherbian","acrylia","grimling","hollowshade","shadeweaver","paludal","sharvahl","katta","mseru","letalis","fungusgrove","sseru","ssratemple","tenebrous","maiden","dawnshroud","scarlet","umbral","akheva","griegsend","thegrey","twilight","vexthal","poknowledge","guildlobby"],
}
def continent_of(short):
    for c, zs in CONTINENT.items():
        if short in zs: return c
    return "Elsewhere"

def thumbnail(short, vs, maps, w=220, h=150):
    """A tiny inked rendering of the zone with its route, for the frontispiece."""
    base = os.path.join(maps, f"{short}.txt")
    lines = parse_lines(base)
    if not lines: return ""
    xs = [l[i] for l in lines for i in (0,3)]; ys = [l[i] for l in lines for i in (1,4)]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    sc = min((w-12)/max(1, x1-x0), (h-12)/max(1, y1-y0))
    ox = (w - (x1-x0)*sc)/2; oy = (h - (y1-y0)*sc)/2
    X = lambda x: (x-x0)*sc + ox; Y = lambda y: (y-y0)*sc + oy
    step = max(1, len(lines)//2500)
    d = " ".join(f"M{X(l[0]):.1f},{Y(l[1]):.1f}L{X(l[3]):.1f},{Y(l[4]):.1f}" for l in lines[::step])
    route = []
    from datetime import datetime as _dt
    import math as _m
    for v in vs:
        prev = None
        for p in v["trail"]:
            q = M(p["loc"])
            if prev:
                dt = (_dt.fromisoformat(p["t"]) - _dt.fromisoformat(prev[1])).total_seconds(); dd = _m.dist(q[:2], prev[0][:2])
                if not (dt > 180 or dd > max(400, 130*dt) or (dd > 100 and dt > 4)):
                    route.append(f"M{X(prev[0][0]):.1f},{Y(prev[0][1]):.1f}L{X(q[0]):.1f},{Y(q[1]):.1f}")
            prev = (q, p["t"])
    return (f'<svg viewBox="0 0 {w} {h}" width="{w}" height="{h}"><path d="{d}" fill="none" stroke="#5a4a38" stroke-width=".6" opacity=".7"/>'
            f'<path d="{" ".join(route)}" fill="none" stroke="#7a2e1e" stroke-width="1.3" stroke-linecap="round" opacity=".9"/></svg>')

def build_index(zones, out, char, generated):
    tot_h = sum(z["hours"] for z in zones.values()); max_h = max([z["hours"] for z in zones.values()] or [1]) or 1
    tot_k = sum(z["kills"] for z in zones.values()); tot_n = sum(z["named"] for z in zones.values())
    mapped = sum(1 for z in zones.values() if z["wire"])
    rows = []
    for short, z in sorted(zones.items(), key=lambda kv: -kv[1]["hours"]):
        name = html.escape(z["zone"]); w = max(2, round(100*z["hours"]/max_h))
        title = f'<a href="{short}_chart.html">{name}</a>' if z["wire"] else f'<span class="dim">{name}</span>'
        rows.append(f'<tr><td class="zone">{title}<span class="bar"><i style="width:{w}%"></i></span></td>'
                    f'<td>{z["hours"]:.1f}</td><td>{z["visits"]}</td><td>{z["locs"]}</td><td>{z["kills"]}</td>'
                    f'<td>{z["named"] or ""}</td><td>{z["deaths"] or ""}</td><td class="dim">{z["last"]}</td></tr>')
    groups = defaultdict(list)
    for short, z in zones.items():
        if z["wire"] and z.get("thumb"): groups[continent_of(short)].append((short, z))
    order = ["Antonica","Faydwer","Kunark","Velious","The Planes","Luclin","Elsewhere"]
    cards = ""
    for c in order:
        if c not in groups: continue
        items = sorted(groups[c], key=lambda kv: kv[1]["zone"])
        cards += f'<h2 style="font:600 13px/1 Cinzel,serif;letter-spacing:.2em;text-transform:uppercase;color:var(--ink-soft);margin:36px 0 12px;padding-bottom:8px;border-bottom:1px solid var(--rule)">{c}</h2><div class="cards">'
        for short, z in items:
            cards += (f'<a class="card" href="{short}_chart.html">{z["thumb"]}<span class="name">{html.escape(z["zone"])}</span>'
                      f'<span class="meta">{z["hours"]:.1f} h · {z["kills"]} kills' + (f' · {z["named"]} named' if z["named"] else '') + (f' · {z["deaths"]} fallen' if z["deaths"] else '') + '</span></a>')
        cards += '</div>'
    page = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{char}'s journey</title>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;600;700&family=EB+Garamond:ital,wght@0,400;0,500;1,400&display=swap" rel="stylesheet">
<style>
:root{{--night:#0a1116;--parch:#e9dcc0;--parch-2:#dccbaa;--ink:#2a2118;--ink-soft:#6b5a45;--gold:#c89b4a;--moss:#7d9c88;--rule:#c9b58e}}
*{{box-sizing:border-box;margin:0}}
body{{background:var(--night);color:var(--ink);font:16px/1.5 "EB Garamond",Georgia,serif;padding:56px 24px 80px}}
main{{max-width:1040px;margin:0 auto;background:linear-gradient(160deg,var(--parch),var(--parch-2));border:1px solid #b89b6a;border-radius:3px;padding:48px 56px 56px;box-shadow:0 0 0 3px rgba(233,220,192,.12),0 24px 60px rgba(0,0,0,.5)}}
.kicker{{font:600 11px/1 Cinzel,serif;letter-spacing:.24em;text-transform:uppercase;color:var(--ink-soft)}}
h1{{font:700 36px/1.1 Cinzel,serif;letter-spacing:.02em;margin-top:8px}}
.rule{{height:1px;width:220px;background:linear-gradient(90deg,var(--gold),transparent);margin:16px 0 14px}}
p.sub{{color:var(--ink-soft);max-width:64ch}}
.totals{{display:flex;gap:44px;margin:34px 0 40px;flex-wrap:wrap}}
.totals div{{display:flex;flex-direction:column}}
.totals b{{font:600 30px/1 Cinzel,serif}}
.totals span{{color:var(--ink-soft);font-size:14px;margin-top:6px}}
table{{border-collapse:collapse;width:100%}}
th{{text-align:left;font:600 11px/1 Cinzel,serif;letter-spacing:.14em;text-transform:uppercase;color:var(--ink-soft);padding:0 14px 10px 0;border-bottom:1px solid var(--rule)}}
td{{padding:11px 14px 11px 0;border-bottom:1px solid var(--rule);vertical-align:middle}}
td:not(.zone),th:not(:first-child){{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}}
td.zone{{width:40%}}
a{{color:#8a5a1f;text-decoration:none;font-weight:500}} a:hover{{text-decoration:underline}}
.dim{{color:var(--ink-soft)}}
a.alt{{font-weight:400;font-style:italic;font-size:13px;color:var(--ink-soft);margin-left:8px}}
.bar{{display:block;height:3px;background:rgba(42,33,24,.12);border-radius:2px;margin-top:7px;max-width:260px}}
.bar i{{display:block;height:100%;background:var(--moss);border-radius:2px}}
tr:hover td{{background:rgba(42,33,24,.05)}}
.cards{{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:18px 20px}}
.card{{display:block;color:var(--ink);text-decoration:none;border:1px solid var(--rule);border-radius:3px;padding:6px;background:rgba(255,255,255,.18);transition:box-shadow .15s}}
.card:hover{{text-decoration:none;box-shadow:0 8px 22px rgba(42,33,24,.18);border-color:#a88b5c}}
.card svg{{display:block;width:100%;height:auto}}
.card .name{{display:block;font:500 15px/1.2 Cinzel,serif;letter-spacing:.02em;margin:8px 4px 2px}}
.card .meta{{display:block;font-size:13px;color:var(--ink-soft);margin:0 4px 4px}}
@media (max-width:640px){{body{{padding:24px 12px}}main{{padding:28px 20px}}h1{{font-size:24px}}th:nth-child(n+4),td:nth-child(n+4){{display:none}}}}
</style></head><body><main>
<div class="kicker">An atlas of</div>
<h1>{char}'s journey through Norrath</h1>
<nav style="margin-top:14px;font-size:15px">{HOME_LINK}<a href="sessions.html">Sessions</a> &nbsp;·&nbsp; <a href="bestiary.html">Bestiary</a> &nbsp;·&nbsp; <a href="fallen.html">The Fallen</a></nav>
<div class="rule"></div>
<p class="sub">Every zone the log has seen. Each card is a chart; the table below has the numbers, and zones without a Brewall map wait there for their files. Last rebuilt {generated[:10]}.</p>
<div class="totals">
  <div><b>{len(zones)}</b><span>zones visited</span></div>
  <div><b>{mapped}</b><span>charted</span></div>
  <div><b>{tot_h:.0f}</b><span>hours logged</span></div>
  <div><b>{tot_k}</b><span>team kills</span></div>
  <div><b>{tot_n}</b><span>named kills</span></div>
</div>
{cards}
<h2 style="font:600 13px/1 Cinzel,serif;letter-spacing:.2em;text-transform:uppercase;color:var(--ink-soft);margin:44px 0 12px;padding-bottom:8px;border-bottom:1px solid var(--rule)">By the numbers</h2>
<table><thead><tr><th>Zone</th><th>Hours</th><th>Visits</th><th>/loc</th><th>Team kills</th><th>Named</th><th>Deaths</th><th>Last there</th></tr></thead>
<tbody>{"".join(rows)}</tbody></table>
</main></body></html>"""
    with open(os.path.join(out, "index.html"), "w", encoding="utf-8") as f: f.write(page)

def build_all(journey_path, maps, out):
    global JOURNEY_PATH
    JOURNEY_PATH = journey_path
    os.makedirs(out, exist_ok=True)
    d = json.load(open(journey_path, encoding="utf-8", errors="replace"))
    load_families(os.path.join(os.path.dirname(journey_path), "mob_families.json"))
    template = None
    by = defaultdict(list)
    for v in d["visits"]:
        if v.get("zone_short"): by[v["zone_short"]].append(v)
    zones = {}
    for short, vs in by.items():
        ev = [e for v in vs for e in v["events"]]
        wire = build_zone(short, vs, maps, out, d["character"], template)
        zones[short] = {"zone": vs[0]["zone"], "visits": len(vs), "hours": sum(hours(v) for v in vs),
                        "locs": sum(len(v["trail"]) for v in vs),
                        "kills": sum(1 for e in ev if e["type"]=="kill" and e.get("team")),
                        "named": sum(1 for e in ev if e["type"]=="kill" and e.get("named")),
                        "deaths": sum(1 for e in ev if e["type"]=="death"), "loot": sum(1 for e in ev if e["type"]=="loot"),
                        "last": vs[-1]["entered"][:10], "wire": wire,
                        "thumb": thumbnail(short, vs, maps) if wire else ""}
        print(f"{'chart' if wire else 'no map yet'}  {vs[0]['zone']}")
    build_index(zones, out, d["character"], d["generated"])
    import build_pages, build_chart
    build_pages.HOME_LINK = HOME_LINK.replace(" &nbsp;·&nbsp; ", "")
    build_pages.build_all(journey_path, out, getattr(build_chart, "JOURNAL", None), {z for z, i in zones.items() if i["wire"]}, TEAM)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--journey", required=True)
    ap.add_argument("--maps", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    sys.path.insert(0, HERE)
    build_all(a.journey, a.maps, a.out)
