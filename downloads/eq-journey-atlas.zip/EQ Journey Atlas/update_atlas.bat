@echo off
rem Update the atlas once: read the logs, redraw the charts, write the in-game map layer.
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (py atlas.py) else (python atlas.py)
echo.
pause
