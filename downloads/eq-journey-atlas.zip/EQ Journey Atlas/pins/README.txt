Custom in-game map pins.
One file per zone, named <zone short name>.txt (e.g. shadowhaven.txt), in EverQuest map-file format:
  P map_x, map_y, z, r, g, b, size, Label_With_Underscores
where map_x = -(second number of /loc) and map_y = -(first number of /loc).
atlas.py appends these lines to the zone's journey layer (<zone>_3.txt in the Brewall maps folder)
on every run, so they survive every rebuild. Lines starting with # are ignored.
