@echo off
rem Keep this window open while you play: the atlas updates itself every 5 minutes.
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (py atlas.py --watch) else (python atlas.py --watch)
pause
