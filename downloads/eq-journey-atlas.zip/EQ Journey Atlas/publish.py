"""
Publish the atlas to a website (GitHub Pages), on a schedule, with no software beyond Python.

atlas.py calls maybe_publish() after every update when "publish" -> "enabled" is true in config.json.
It publishes when there is something new AND either `every_minutes` have passed since the last
publish, or the log has gone quiet for `idle_minutes` (you logged off) - so the site always ends on
your latest session without being re-uploaded every few minutes.

What gets published is a separate public copy, built into the `public` folder next to this file
(open public/atlas/index.html to see exactly what the world will see):
  * your own characters (config "team", plus any names in publish -> "show_names") keep their names;
  * every other player becomes "the raid" ("A raid member" when they die), in charts, the bestiary,
    the sessions page and your journal notes;
  * loot is left out entirely.
Your own atlas in the `journey` folder is never changed.

Uploading uses the GitHub API with a token kept in github_token.txt (never published). Only files
that changed since the last publish are uploaded, and the site branch keeps no history, so the
repository stays small however long you play.
"""
import base64, glob, hashlib, json, os, re, shutil, time, urllib.error, urllib.request
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
PUBLIC = os.path.join(HERE, "public")              # what the world sees (preview it locally)
PUBLIC_DATA = os.path.join(HERE, "public_data")    # the anonymised journey the public pages are built from
STATE = os.path.join(HERE, "publish_state.json")
TOKEN_FILE = os.path.join(HERE, "github_token.txt")
API = "https://api.github.com"

DEFAULTS = {"enabled": False, "github_repo": "", "branch": "gh-pages", "site_folder": "site",
            "custom_domain": "", "every_minutes": 30, "idle_minutes": 10,
            "other_players": "the raid", "other_player_died": "A raid member",
            "show_names": [], "publish_screenshots": True, "home_label": "Home"}

def settings(cfg):
    return {**DEFAULTS, **(cfg.get("publish") or {})}

# ---------------------------------------------------------------- the public copy

def owner(name):
    """'Katze`s pet' -> 'Katze'; any other name is returned as it is."""
    m = re.match(r"^(\w+)[`']s (?:pet|warder|familiar|ward)\b", name)
    return m.group(1) if m else name.strip()

def other_players(d, keep):
    """Names of other players in the journey: anyone who died, or who landed a kill and is a single
    capitalised word that is never itself a mob we fought. Pets count as their owner."""
    mobs = {e["mob"] for v in d["visits"] for e in v["events"] if e["type"] == "kill"}
    found = set()
    for v in d["visits"]:
        for e in v["events"]:
            if e["type"] == "death":
                found.add(owner(e["who"]))
            elif e["type"] == "kill":
                b = owner(e["by"])
                if b and " " not in b and b[0].isupper() and b not in mobs and b not in ("Your", "You"):
                    found.add(b)
    return {n for n in found if n and n not in keep}

def public_journey(d, cfg):
    """A copy of the journey with other players' names replaced and loot removed."""
    p = settings(cfg)
    keep = set(cfg.get("team") or []) | set(p["show_names"]) | {d.get("character") or ""}
    label, died = p["other_players"], p["other_player_died"]
    others = other_players(d, keep) if label else set()
    def swap(name, repl): return repl if owner(name) in others else name
    out = {k: v for k, v in d.items() if k not in ("visits", "log_offsets")}
    out["visits"] = []
    for v in d["visits"]:
        ev = []
        for e in v["events"]:
            if e["type"] == "loot": continue
            e = dict(e)
            if e["type"] == "kill": e["by"] = swap(e["by"], label)
            elif e["type"] == "death": e["who"] = swap(e["who"], died); e["by"] = swap(e["by"], label)
            ev.append(e)
        out["visits"].append({**v, "events": ev})
    return out, others

def scrub_text(text, others, label):
    if not others: return text
    pat = re.compile(r"\b(" + "|".join(re.escape(n) for n in sorted(others, key=len, reverse=True)) + r")\b")
    return pat.sub(label, text)

def build_public(cfg):
    """Build the public pages into PUBLIC/atlas from an anonymised copy of the journey."""
    import build_viewer as viewer, build_chart, build_pages
    p = settings(cfg)
    d = json.load(open(os.path.join(cfg["out"], "eq_journey.json"), encoding="utf-8", errors="replace"))
    pub, others = public_journey(d, cfg)
    os.makedirs(PUBLIC_DATA, exist_ok=True)
    jpath = os.path.join(PUBLIC_DATA, "eq_journey.json")
    json.dump(pub, open(jpath, "w", encoding="utf-8"), indent=0)
    for f in ("named_mobs.json", "mob_families.json"):
        src = os.path.join(cfg["out"], f)
        if os.path.exists(src): shutil.copy2(src, os.path.join(PUBLIC_DATA, f))

    out = os.path.join(PUBLIC, "atlas")
    if os.path.isdir(out): shutil.rmtree(out)
    os.makedirs(out)
    journal = build_chart.load_journal(os.path.join(HERE, "journal.md"))
    # in your notes, only swap words that are clearly player names (not also part of a zone or mob name)
    words = {w for v in d["visits"] for w in re.findall(r"\w+", v.get("zone") or "")}
    words |= {w for v in d["visits"] for e in v["events"] if e["type"] == "kill" for w in re.findall(r"\w+", e["mob"])}
    journal = {z: [(dt, scrub_text(t, others - words, p["other_players"])) for dt, t in notes] for z, notes in journal.items()}

    shots = None
    if p["publish_screenshots"] and os.path.isdir(cfg["shots"]) and any(
            f for _, _, fs in os.walk(cfg["shots"]) for f in fs if f.lower().endswith(build_chart.SHOT_EXT)):
        shots = os.path.join(out, "screenshots")
        shutil.copytree(cfg["shots"], shots, ignore=lambda dir_, fs: [f for f in fs
                        if os.path.isfile(os.path.join(dir_, f)) and not f.lower().endswith(build_chart.SHOT_EXT)])

    saved = (viewer.TEAM, viewer.HOME_LINK, build_pages.HOME_LINK, build_chart.JOURNAL, build_chart.SHOTS_DIR, viewer.JOURNEY_PATH)
    try:
        viewer.TEAM = set(cfg["team"])
        viewer.HOME_LINK = f'<a href="../index.html">{p["home_label"]}</a> &nbsp;·&nbsp; '
        build_chart.JOURNAL, build_chart.SHOTS_DIR = journal, shots
        viewer.JOURNEY_PATH = jpath
        viewer.build_all(jpath, cfg["maps_dir"], out)
    finally:
        viewer.TEAM, viewer.HOME_LINK, build_pages.HOME_LINK, build_chart.JOURNAL, build_chart.SHOTS_DIR, viewer.JOURNEY_PATH = saved
    write_stats(pub, cfg, out)
    site = os.path.join(HERE, "site")                 # optional hand-made front pages, published at the root
    if os.path.isdir(site):
        for root, _, files in os.walk(site):
            for f in files:
                src = os.path.join(root, f); dst = os.path.join(PUBLIC, os.path.relpath(src, site))
                os.makedirs(os.path.dirname(dst), exist_ok=True); shutil.copy2(src, dst)
    for f in glob.glob(os.path.join(out, "*_journey.txt")): os.remove(f)    # in-game layer files stay private
    for f in glob.glob(os.path.join(out, "*.json")):
        if not f.endswith("stats.json"): os.remove(f)
    print(f"Public pages built: {out} ({len(others)} other players shown as \"{p['other_players']}\")")
    return PUBLIC

def write_stats(d, cfg, out):
    """atlas/stats.json: totals and the latest zones with their thumbnails, for a front page to show."""
    import build_viewer as viewer
    from collections import defaultdict
    by = defaultdict(list)
    for v in d["visits"]:
        if v.get("zone_short"): by[v["zone_short"]].append(v)
    charted = {z for z in by if os.path.exists(os.path.join(out, f"{z}_chart.html"))}
    ev = [e for v in d["visits"] for e in v["events"]]
    last = {z: max(x["entered"] for x in vs) for z, vs in by.items()}
    fought = {z for z in charted if any(e["type"] == "kill" and e.get("team") for v in by[z] for e in v["events"])}
    recent = sorted(fought or charted, key=lambda z: last[z], reverse=True)[:6]
    stats = {
        "character": d.get("character"), "team": cfg.get("team") or [],
        "updated": datetime.now().isoformat(timespec="minutes"),
        "since": min((v["entered"] for v in d["visits"]), default="")[:10],
        "zones": len(by), "charted": len(charted),
        "hours": round(sum(viewer.hours(v) for v in d["visits"] if v.get("zone_short"))),
        "kills": sum(1 for e in ev if e["type"] == "kill" and e.get("team")),
        "named": sum(1 for e in ev if e["type"] == "kill" and e.get("named")),
        "recent": [{"zone": by[z][0]["zone"], "href": f"atlas/{z}_chart.html", "last": last[z][:10],
                    "thumb": viewer.thumbnail(z, by[z], cfg["maps_dir"])} for z in recent],
    }
    json.dump(stats, open(os.path.join(out, "stats.json"), "w", encoding="utf-8"))

# ---------------------------------------------------------------- GitHub upload

def token():
    t = os.environ.get("GITHUB_TOKEN") or (open(TOKEN_FILE, encoding="utf-8").read().strip() if os.path.exists(TOKEN_FILE) else "")
    if not t:
        raise RuntimeError("no GitHub token. Put it in github_token.txt next to atlas.py (see README, 'Publishing').")
    return t

def gh(method, path, body=None, ok404=False):
    req = urllib.request.Request(API + path, method=method, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Authorization": f"Bearer {token()}", "Accept": "application/vnd.github+json",
                                          "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "eq-journey-atlas"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                raw = r.read()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            if e.code == 404 and ok404: return None
            if e.code in (502, 503, 504) and attempt < 3: time.sleep(3 * (attempt + 1)); continue
            msg = e.read().decode(errors="replace")[:300]
            raise RuntimeError(f"GitHub said {e.code} to {method} {path}: {msg}")
        except urllib.error.URLError as e:
            if attempt < 3: time.sleep(3 * (attempt + 1)); continue
            raise RuntimeError(f"couldn't reach GitHub ({e.reason})")

def blob_sha(data):
    return hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()

def tree_of(repo, ref):
    """{path: sha} for every file on a branch, or {} if the branch doesn't exist."""
    r = gh("GET", f"/repos/{repo}/git/trees/{ref}?recursive=1", ok404=True)
    if not r: return {}
    return {t["path"]: t["sha"] for t in r["tree"] if t["type"] == "blob"}

def upload(cfg, folder):
    """Make the site branch exactly: the repo's site folder + everything in `folder` (+ CNAME)."""
    p = settings(cfg); repo, branch = p["github_repo"], p["branch"]
    if not repo or "/" not in repo:
        raise RuntimeError('set publish -> "github_repo" in config.json, e.g. "YourName/eq-atlas"')
    info = gh("GET", f"/repos/{repo}")
    main = info["default_branch"]
    entries = {}                                                     # path -> sha
    site = p["site_folder"].strip("/")
    for path, sha in tree_of(repo, main).items():                    # the hand-made front pages
        if site and path.startswith(site + "/"): entries[path[len(site) + 1:]] = sha
    remote = set(tree_of(repo, branch).values()) | set(entries.values())
    sent = 0
    for root, _, files in os.walk(folder):
        for f in files:
            full = os.path.join(root, f)
            rel = os.path.relpath(full, folder).replace("\\", "/")
            data = open(full, "rb").read()
            sha = blob_sha(data)
            if sha not in remote:
                gh("POST", f"/repos/{repo}/git/blobs", {"content": base64.b64encode(data).decode(), "encoding": "base64"})
                remote.add(sha); sent += 1
            entries[rel] = sha
    extra = {".nojekyll": "\n"}
    if p["custom_domain"]: extra["CNAME"] = p["custom_domain"].strip() + "\n"
    tree = [{"path": k, "mode": "100644", "type": "blob", "sha": v} for k, v in sorted(entries.items()) if k not in extra]
    tree += [{"path": k, "mode": "100644", "type": "blob", "content": v} for k, v in extra.items()]
    t = gh("POST", f"/repos/{repo}/git/trees", {"tree": tree})
    c = gh("POST", f"/repos/{repo}/git/commits", {"message": f"Atlas published {datetime.now():%Y-%m-%d %H:%M}", "tree": t["sha"], "parents": []})
    if gh("GET", f"/repos/{repo}/git/ref/heads/{branch}", ok404=True) is not None:
        gh("PATCH", f"/repos/{repo}/git/refs/heads/{branch}", {"sha": c["sha"], "force": True})
    else:
        gh("POST", f"/repos/{repo}/git/refs", {"ref": f"refs/heads/{branch}", "sha": c["sha"]})
        try:   # first publish: switch GitHub Pages on for this branch (needs the token's Pages permission)
            gh("POST", f"/repos/{repo}/pages", {"source": {"branch": branch, "path": "/"}})
        except RuntimeError as e:
            note(f"Turn on GitHub Pages for the '{branch}' branch in the repository's settings ({e})")
    note(f"Published to {repo} ({branch}): {len(entries)} files, {sent} uploaded.")

# ---------------------------------------------------------------- schedule

def fingerprint(cfg):
    h = hashlib.sha1()
    for f in [os.path.join(cfg["out"], "eq_journey.json"), os.path.join(HERE, "journal.md")]:
        if os.path.exists(f): h.update(open(f, "rb").read())
    site = os.path.join(HERE, "site")                 # front pages, and the ledger's public copy
    if os.path.isdir(site):
        for root, _, fs in sorted(os.walk(site)):
            for f in sorted(fs): h.update(open(os.path.join(root, f), "rb").read())
    if os.path.isdir(cfg["shots"]):
        for root, _, fs in os.walk(cfg["shots"]):
            for f in sorted(fs): h.update(f"{f}{os.path.getsize(os.path.join(root, f))}".encode())
    return h.hexdigest()

LOG = os.path.join(HERE, "publish_log.txt")

def note(msg):
    """Print, and keep the last few hundred lines in publish_log.txt."""
    print(msg)
    try:
        lines = open(LOG, encoding="utf-8").read().splitlines()[-300:] if os.path.exists(LOG) else []
        lines.append(f"{datetime.now():%Y-%m-%d %H:%M:%S}  {msg}")
        open(LOG, "w", encoding="utf-8").write("\n".join(lines) + "\n")
    except OSError:
        pass

def maybe_publish(cfg, logs, force=False):
    try:
        _maybe_publish(cfg, logs, force)
    except Exception as e:
        note(f"Publish failed: {e}")

def _maybe_publish(cfg, logs, force=False):
    p = settings(cfg)
    state = json.load(open(STATE, encoding="utf-8")) if os.path.exists(STATE) else {}
    fp, now = fingerprint(cfg), time.time()
    if fp == state.get("fingerprint") and not force:
        return print("Publish: nothing new since the last publish.")   # not logged: this is most runs
    since = (now - state["at"]) / 60 if state.get("at") else None
    quiet = (now - max(os.path.getmtime(l) for l in logs)) / 60 if logs else 1e9
    if not force and since is not None and since < p["every_minutes"] and quiet < p["idle_minutes"]:
        return print(f"Publish: next in about {p['every_minutes'] - since:.0f} minutes (or {p['idle_minutes']} minutes after you stop playing).")
    note("Publishing...")
    upload(cfg, build_public(cfg))
    json.dump({"at": now, "fingerprint": fp, "when": datetime.now().isoformat(timespec="seconds")},
              open(STATE, "w", encoding="utf-8"), indent=1)

if __name__ == "__main__":
    # python publish.py --preview : build the public pages only, to look at before anything goes online
    import sys, atlas
    cfg = atlas.load_config()
    build_public(cfg)
    if "--preview" not in sys.argv:
        upload(cfg, PUBLIC)
