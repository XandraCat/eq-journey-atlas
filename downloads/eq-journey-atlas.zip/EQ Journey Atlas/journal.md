# Journey journal

Write a note under a heading of the form `## <zone> - <YYYY-MM-DD>` and it appears on that zone's
chart (the three newest notes per zone) and on that day in Sessions. The zone can be the map name
(paw, kael) or the full name. Delete the example below whenever you like.

## The Lair of the Splitpaw - 2026-01-01
An example note: the first night of the atlas. The gnolls did not go quietly.
