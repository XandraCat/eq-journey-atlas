#!/usr/bin/env python3
"""
EverQuest journey log parser.

Reads one or more eqlog_<Char>_<server>.txt files and produces:
  1. <out>/eq_journey.json        - every /loc, kill, death, loot, level-up,
                                     zone change, grouped by zone visit, with
                                     each event pinned to the most recent /loc.
  2. <out>/<zone>_journey.txt     - one in-game map layer file per zone
                                     (points for kills, deaths, level-ups,
                                     a coloured line for your trail).

Usage:
    python eq_log_parser.py eqlog_<Character>_<server>.txt [more logs...] --out journey/

Coordinates:
    /loc prints  "Your Location is Y, X, Z".
    Map files store  x = -X,  y = -Y,  z = Z.
    Change FLIP below if a test marker lands in the wrong spot in-game.
"""
import re, sys, json, argparse, os
from datetime import datetime
from collections import defaultdict

FLIP = True                       # map_x = -loc_x, map_y = -loc_y
TEAM = set()                      # your characters; set from config.json via set_team()
STALE_AFTER = 120                 # seconds between an event and its nearest /loc before we call the fix "stale"
TRAIL_MIN_STEP = 12               # in-game layer: skip trail points closer than this to the last kept point
GAP_SECONDS = 180                 # a break in the route: no line drawn between readings further apart in time than this
GAP_SPEED = 130                   # ... or moving faster than this (units/sec) - a port or teleporter, not a run
GAP_DIST = 400

TS_RE   = re.compile(r"^\[(\w{3} \w{3} \d{2} \d{2}:\d{2}:\d{2} \d{4})\] (.*)$")
LOC_RE  = re.compile(r"^Your Location is (-?[\d.]+), (-?[\d.]+), (-?[\d.]+)")
ZONE_RE = re.compile(r"^You have entered (.+)\.$")
YOU_SLAIN_RE   = re.compile(r"^You have slain (.+)!$")
OTHER_SLAIN_RE = re.compile(r"^(.+?) was slain by (.+?)!$")
YOU_DIED_RE    = re.compile(r"^You have been slain by (.+)!$")
ALLY_DIED_RE   = re.compile(r"^(\w+) has been slain by (.+)!$")
LOOT_RE   = re.compile(r"^--You have looted (?:an? |\d+ )?(.+?) from (.+?)'s corpse\.--$")
LEVEL_RE  = re.compile(r"^You have gained a level! Welcome to level (\d+)!$")
EXP_RE    = re.compile(r"^You gain (?:party )?experience")

# Long zone name -> map file short name. Add as you go.
ZONE_SHORT = {
    "The Lair of the Splitpaw": "paw",
    "The Southern Plains of Karana": "southkarana",
    "The Skyfire Mountains": "skyfire",
    "The Overthere": "overthere",
    "The Commonlands": "commonlands",
    "The Bazaar": "bazaar",
    "The Western Wastes": "westwastes",
    "Dragon Necropolis": "necropolis",
    "Siren's Grotto": "sirens",
    "The Plane of Knowledge": "poknowledge",
    "The Guild Lobby": "guildlobby",
    "South Desert of Ro": "southro",
    "North Desert of Ro": "northro",
    "The Castle of Mistmoore": "mistmoore",
    "West Freeport": "freportw",
    "Butcherblock Mountains": "butcher",
    "Icewell Keep": "thurgadinb",
    "The Great Divide": "greatdivide",
    "The City of Thurgadin": "thurgadina",
    "The Wakening Land": "wakening",
    "The Wakening Lands": "wakening",
    "Skyshrine": "skyshrine",
    "Kael Drakkel": "kael",
    "The Burning Woods": "burningwood",
    "The Dreadlands": "dreadlands",
    "Karnor's Castle": "karnor",
    "The Sleeper's Tomb": "sleeper",
    "Eastern Wastes": "eastwastes",
    "Halas": "halas",
    "Northern Felwithe": "felwithea",
    "Southern Felwithe": "felwitheb",
}
SKIP_ZONE_PREFIX = ("an area",)   # "You have entered an area where Bind Affinity is allowed."

def set_team(names): 
    global TEAM; TEAM = set(names)

def load_zone_names(path):
    """Extra long-name -> map-file-name entries from zone_names.json (user-editable)."""
    if path and os.path.exists(path):
        ZONE_SHORT.update({k: v for k, v in json.load(open(path, encoding="utf-8", errors="replace")).items() if not k.startswith("_")})

def short_zone(name):
    if name in ZONE_SHORT:
        return ZONE_SHORT[name]
    return re.sub(r"[^a-z0-9]", "", name.lower().replace("the ", ""))

def parse_ts(s):
    return datetime.strptime(s, "%a %b %d %H:%M:%S %Y")

def to_map(loc):
    y, x, z = loc
    return (-x, -y, z) if FLIP else (x, y, z)

def parse(paths, start_zone=None, char=None, offsets=None):
    offsets = offsets or {}; new_offsets = {}
    visits = []          # list of zone visits, in order
    cur = None
    last_loc = None      # (ts, (y,x,z))

    def new_visit(zone, ts):
        nonlocal cur, last_loc
        cur = {"zone": zone, "zone_short": short_zone(zone) if zone else None, "entered": ts.isoformat(),
               "left": None, "trail": [], "events": []}
        visits.append(cur)
        last_loc = None

    default_char = char
    for path in paths:
        m = re.search(r"eqlog_(\w+)_", os.path.basename(path))
        char = m.group(1) if m else default_char
        cur = None; last_loc = None
        key = os.path.basename(path).lower(); size = os.path.getsize(path)
        start = offsets.get(key, 0)
        if start > size: start = 0                      # the log was trimmed or replaced: read it all again
        with open(path, "rb") as fb:
            if start:
                fb.seek(start - 1)
                if fb.read(1) != b"\n":                   # previous read ended mid-line: skip the rest of it
                    fb.readline()
            text = fb.read().decode("utf-8", "replace")
        new_offsets[key] = size
        if True:
            for raw in text.splitlines():
                m = TS_RE.match(raw.rstrip("\r\n"))
                if not m: continue
                ts, msg = parse_ts(m.group(1)), m.group(2)

                z = ZONE_RE.match(msg)
                if z and not z.group(1).startswith(SKIP_ZONE_PREFIX):
                    if cur: cur["left"] = ts.isoformat()
                    new_visit(z.group(1), ts)
                    continue
                if cur is None:
                    new_visit(start_zone, ts)   # log started mid-zone: open an unnamed visit; merge attaches it to the last open one

                l = LOC_RE.match(msg)
                if l:
                    loc = tuple(float(v) for v in l.groups())
                    last_loc = (ts, loc)
                    cur["trail"].append({"t": ts.isoformat(), "loc": loc})
                    continue

                ev = None
                if (k := YOU_SLAIN_RE.match(msg)):
                    ev = {"type": "kill", "mob": k.group(1), "by": char or "you", "named": is_named(k.group(1), cur["zone_short"])}
                elif (k := YOU_DIED_RE.match(msg)):
                    ev = {"type": "death", "who": char or "you", "by": k.group(1)}
                elif (k := ALLY_DIED_RE.match(msg)):
                    ev = {"type": "death", "who": k.group(1), "by": k.group(2)}
                elif (k := OTHER_SLAIN_RE.match(msg)):
                    ev = {"type": "kill", "mob": norm_mob(k.group(1)), "by": k.group(2), "named": is_named(norm_mob(k.group(1)), cur["zone_short"])}
                elif (k := LOOT_RE.match(msg)):
                    ev = {"type": "loot", "item": k.group(1), "from": k.group(2)}
                elif (k := LEVEL_RE.match(msg)):
                    ev = {"type": "level", "level": int(k.group(1))}
                if ev:
                    if ev["type"] == "kill": ev["team"] = is_team(ev["by"])
                    ev["t"] = ts.isoformat()
                    cur["events"].append(ev)
    for v in visits:
        pin_events(v)
    return {"character": char, "generated": datetime.now().isoformat(), "visits": visits, "log_offsets": new_offsets}

def merge(old, new):
    """Fold newly parsed visits into an existing journey. A log that starts mid-zone
    (first visit has zone None) continues the last visit in the old journey."""
    visits = old["visits"]
    for v in new["visits"]:
        if v["zone"] is None:
            # log starts mid-zone: attach to the old visit that was in progress at that time
            before = [o for o in visits if o["entered"] <= v["entered"]]
            if not before: continue
            tgt = before[-1]
            if tgt["left"] and tgt["left"] < v["entered"] and not v["trail"] and not v["events"]: continue
        else:
            tgt = next((o for o in visits if o["zone"] == v["zone"] and o["entered"] == v["entered"]), None)
            if tgt is None:
                visits.append(v); continue
        seen_t = {p["t"] for p in tgt["trail"]}
        tgt["trail"] += [p for p in v["trail"] if p["t"] not in seen_t]
        tgt["trail"].sort(key=lambda p: p["t"])
        key = lambda e: (e["t"], e["type"], str(e.get("mob") or e.get("item") or e.get("who") or e.get("level")).lower())
        seen_e = {key(e) for e in tgt["events"]}
        tgt["events"] += [e for e in v["events"] if key(e) not in seen_e]
        tgt["events"].sort(key=lambda e: e["t"])
        if v["left"]: tgt["left"] = v["left"]
        pin_events(tgt)
    old["character"] = old.get("character") or new["character"]
    old["generated"] = new["generated"]
    old.setdefault("log_offsets", {}).update(new.get("log_offsets", {}))
    return old

def pin_events(v):
    """Attach each event to the /loc reading nearest in time (before OR after it)."""
    trail = [(datetime.fromisoformat(p["t"]), p["loc"]) for p in v["trail"]]
    for e in v["events"]:
        if not trail:
            e.update({"loc": None, "loc_age_s": None, "stale": True}); continue
        t = datetime.fromisoformat(e["t"])
        best = min(trail, key=lambda p: abs((p[0] - t).total_seconds()))
        age = int(abs((best[0] - t).total_seconds()))
        e.update({"loc": best[1], "loc_age_s": age, "stale": age > STALE_AFTER})

NAMED = {}   # zone_short -> set of named mob names, loaded from named_mobs.json

IGNORE = {}  # zone_short -> capitalised mobs that are NOT named; silences the candidate report

def load_named(path):
    global NAMED, IGNORE
    if path and os.path.exists(path):
        raw = json.load(open(path, encoding="utf-8", errors="replace"))
        IGNORE = {z: set(n.lower() for n in names) for z, names in raw.pop("_ignore", {}).items()}
        NAMED = {z: set(names) for z, names in raw.items() if not z.startswith("_")}

def looks_named(mob):
    """Capitalisation heuristic only - used to flag CANDIDATES for review, not to decide."""
    words = mob.split()
    if re.match(r"^(a|an|the)$", words[0], re.I): return False
    return all(w[0].isupper() or w.lower() in ("of", "the") for w in words)

def is_named(mob, zone_short=None):
    """A mob is named only if it's on the zone's list in named_mobs.json (case-insensitive)."""
    m = mob.lower()
    return any(m == n.lower() for n in NAMED.get(zone_short, set()) | NAMED.get("*", set()))

def named_case(mob, zone_short=None):
    """Return the list's spelling of a named mob (so 'the Avatar of War' shows as 'The Avatar of War')."""
    m = mob.lower()
    return next((n for n in NAMED.get(zone_short, set()) | NAMED.get("*", set()) if n.lower() == m), mob)

def norm_mob(mob):
    """'A hiding gnoll' (sentence-start capital) -> 'a hiding gnoll'; leaves capitalised names alone."""
    if looks_named(mob): return mob
    return mob[0].lower() + mob[1:]

def is_team(name):
    """True for a team member or a team member's pet (e.g. "Katze`s pet")."""
    return name.split("`")[0].split("'")[0] in TEAM or name in ("Your", "Your pet")

# In-game layer colours (r,g,b) - dark tones read best on the tan map background
LAYER_TRAIL  = "220, 30, 30"     # route: red
LAYER_KILLS  = "120, 30, 30"     # camps: dark red
LAYER_NAMED  = "170, 20, 40"     # named slain: crimson, name only
LAYER_DEATH  = "40, 40, 40"      # deaths: charcoal
LAYER_LEVEL  = "200, 90, 0"      # level gained: burnt orange
KILL_CLUSTER = 40                # kills within this many units become one "N_kills" point
SHOW_CAMPS   = False             # ordinary kills on the in-game map (the chart always has them)

def star_lines(x, y, z, r, colour):
    """An eight-point star of line segments around a point, so a named kill stands out at any zoom."""
    import math
    out = []
    for i in range(8):
        a = i * math.pi / 4; b = a + math.pi / 8
        ro = r if i % 2 == 0 else r * 0.55
        for (x1, y1), (x2, y2) in (((x + math.cos(a)*ro, y + math.sin(a)*ro), (x + math.cos(b)*r*0.45, y + math.sin(b)*r*0.45)),):
            out.append(f"L {x1:.2f}, {y1:.2f}, {z:.2f}, {x2:.2f}, {y2:.2f}, {z:.2f}, {colour}")
        nb = (i + 1) * math.pi / 4
        out.append(f"L {x + math.cos(b)*r*0.45:.2f}, {y + math.sin(b)*r*0.45:.2f}, {z:.2f}, {x + math.cos(nb)*(r if (i+1) % 2 == 0 else r*0.55):.2f}, {y + math.sin(nb)*(r if (i+1) % 2 == 0 else r*0.55):.2f}, {z:.2f}, {colour}")
    return out

def write_layers(data, out):
    """One map layer per zone: trail line + points for pinned events.
    Trash kills are clustered into one point with a count so the map stays legible; named, deaths and
    level-ups get their own labelled points."""
    by_zone = defaultdict(list)
    for v in data["visits"]:
        by_zone[v["zone_short"]].append(v)
    for zone, vs in by_zone.items():
        lines = []; clusters = []
        for v in vs:
            tr = []
            for p in v["trail"]:
                if not tr or sum((a-b)**2 for a, b in zip(p["loc"], tr[-1][1])) >= TRAIL_MIN_STEP**2:
                    tr.append((datetime.fromisoformat(p["t"]), p["loc"]))
            for (ta, a), (tb, b) in zip(tr, tr[1:]):
                dt = (tb - ta).total_seconds(); dd = sum((p-q)**2 for p, q in zip(a, b))**0.5
                if dt > GAP_SECONDS or dd > max(GAP_DIST, GAP_SPEED*dt) or (dd > 100 and dt > 4):
                    continue
                (x1, y1, z1), (x2, y2, z2) = to_map(a), to_map(b)
                lines.append(f"L {x1:.2f}, {y1:.2f}, {z1:.2f}, {x2:.2f}, {y2:.2f}, {z2:.2f}, {LAYER_TRAIL}")
            for e in v["events"]:
                if e["loc"] is None or e["stale"]: continue
                x, y, z = to_map(e["loc"])
                if e["type"] == "kill" and e.get("named"):
                    lines.append(f"P {x:.2f}, {y:.2f}, {z:.2f}, {LAYER_NAMED}, 2, {e['mob'].replace(' ','_')}")
                elif e["type"] == "kill" and SHOW_CAMPS and is_team(e["by"]):
                    c = next((c for c in clusters if (c[0]-x)**2 + (c[1]-y)**2 < KILL_CLUSTER**2 and abs(c[2]-z) < 15), None)
                    if c: c[3] += 1
                    else: clusters.append([x, y, z, 1])
                elif e["type"] == "death":
                    lines.append(f"P {x:.2f}, {y:.2f}, {z:.2f}, {LAYER_DEATH}, 2, {e['who']}_fell")
                elif e["type"] == "level":
                    lines.append(f"P {x:.2f}, {y:.2f}, {z:.2f}, {LAYER_LEVEL}, 2, Level_{e['level']}")
        for x, y, z, n in clusters:
            size = 1 if n < 5 else 2 if n < 20 else 3
            lines.append(f"P {x:.2f}, {y:.2f}, {z:.2f}, {LAYER_KILLS}, {size}, {n}_kills" if n > 1 else f"P {x:.2f}, {y:.2f}, {z:.2f}, {LAYER_KILLS}, 1, a_kill")
        if lines:
            with open(os.path.join(out, f"{zone}_journey.txt"), "w", encoding="utf-8") as f:
                f.write("\n".join(lines) + "\n")

def candidates(data):
    """Capitalised mobs the team killed that aren't on the named list - review and add the real ones."""
    seen = defaultdict(set)
    for v in data["visits"]:
        for e in v["events"]:
            if e["type"] == "kill" and e.get("team") and looks_named(e["mob"]) and not e.get("named") \
               and e["mob"].lower() not in IGNORE.get(v["zone_short"], set()):
                seen[v["zone_short"]].add(e["mob"])
    if seen:
        print("\nUnlisted capitalised mobs (add real named ones to named_mobs.json):")
        for z, names in seen.items(): print(f"  {z}: {', '.join(sorted(names))}")

def summary(data):
    for v in data["visits"]:
        n = len(v["events"])
        if not v["trail"] and n == 0: continue
        kills = sum(1 for e in v["events"] if e["type"] == "kill")
        mine  = sum(1 for e in v["events"] if e["type"] == "kill" and is_team(e["by"]))
        pinned = sum(1 for e in v["events"] if e["loc"] and not e["stale"])
        print(f"{v['entered'][:16]}  {(v['zone'] or '(unknown zone)'):<32} loc:{len(v['trail']):>3}  kills:{kills:>3} (team {mine:>3})  "
              f"deaths:{sum(1 for e in v['events'] if e['type']=='death'):>2}  loot:{sum(1 for e in v['events'] if e['type']=='loot'):>2}  pinned:{pinned}")

def run(logs, out, char=None, start_zone=None, fresh=False, named=None):
    """Parse logs, merge into <out>/eq_journey.json, write per-zone layer files. Returns the journey."""
    os.makedirs(out, exist_ok=True)
    load_named(named or os.path.join(out, "named_mobs.json"))
    jpath = os.path.join(out, "eq_journey.json")
    old = json.load(open(jpath, encoding="utf-8", errors="replace")) if os.path.exists(jpath) and not fresh else None
    char = char or (old or {}).get("character")
    data = parse(logs, start_zone, char, (old or {}).get("log_offsets") if not fresh else None)
    if old:
        data = merge(old, data)
    data["character"] = char or data.get("character")
    for v in data["visits"]:
        for e in v["events"]:
            if e["type"] == "kill":
                if e.get("by") == "you" and data.get("character"): e["by"] = data["character"]
                e["team"] = is_team(e["by"])
                e["named"] = is_named(e["mob"], v["zone_short"])
                if e["named"]: e["mob"] = named_case(e["mob"], v["zone_short"])
            elif e["type"] == "death" and e.get("who") == "you" and data.get("character"):
                e["who"] = data["character"]
    with open(jpath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=1)
    write_layers(data, out)
    return data

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("logs", nargs="+")
    ap.add_argument("--out", default="journey")
    ap.add_argument("--named", default=None, help="named_mobs.json (default: <out>/named_mobs.json)")
    ap.add_argument("--start-zone", default=None, help="zone the log starts in, if it begins mid-zone")
    ap.add_argument("--char", default=None, help="character name (default: from the log filename, or the existing journey)")
    ap.add_argument("--fresh", action="store_true", help="ignore an existing eq_journey.json instead of merging into it")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    load_named(a.named or os.path.join(a.out, "named_mobs.json"))
    jpath = os.path.join(a.out, "eq_journey.json")
    old = json.load(open(jpath, encoding="utf-8", errors="replace")) if os.path.exists(jpath) and not a.fresh else None
    char = a.char or (old or {}).get("character")
    data = parse(a.logs, a.start_zone, char)
    if old:
        data = merge(old, data)
    for v in data["visits"]:                      # named list may have changed since events were stored
        for e in v["events"]:
            if e["type"] == "kill":
                if e.get("by") == "you" and data.get("character"): e["by"] = data["character"]
                e["team"] = is_team(e["by"])
                e["named"] = is_named(e["mob"], v["zone_short"])
                if e["named"]: e["mob"] = named_case(e["mob"], v["zone_short"])
    with open(jpath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=1)
    write_layers(data, a.out)
    summary(data)
    candidates(data)
